# CHANGELOG

## 0.2.0 (2025-02-24)

- Updated dependencies
- Updated EsLint configuration to v9
- Updated TailwindCSS to v4
- Updated dark theme colors to a less contrasting color palette
- Updated the UI components to use the new spacing system in TailwindCSS v4
- Minor bug fixes ported from the full kit

## 0.1.0

- Initial release of the Next.js Supabase SaaS Kit Lite template