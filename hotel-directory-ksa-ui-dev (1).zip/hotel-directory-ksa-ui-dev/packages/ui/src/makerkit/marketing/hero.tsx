'use client';

import React, { useEffect, useRef } from 'react';
import Box from '@mui/material/Box';

export function Hero({ children }: { children: React.ReactNode }) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.play().catch((error) => {
        console.log('Video autoplay failed:', error);
      });
    }
  }, []);

  return (
    <Box
      component="section"
      sx={{
        position: 'relative',
        width: '100%',
        height: { xs: 800, md: 700 },
        overflow: 'hidden',
      }}
    >
      {/* Background Video */}
      <Box
        sx={{
          position: 'absolute',
          inset: 0,
          zIndex: 0,
        }}
      >
        <video
          ref={videoRef}
          autoPlay
          muted
          loop
          playsInline
          poster="/images/hero-bg-poster.jpg"
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            position: 'absolute',
            top: 0,
            left: 0,
          }}
        >
          <source src="/images/hero-bg-video.webm" type="video/webm" />
          <source src="/images/hero-bg-video.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>

        

        {/* Dark Overlay */}
        <Box
          sx={{
            position: 'absolute',
            inset: 0,
            background:
              'linear-gradient(to bottom, rgba(0,0,0,0.75), rgba(0,0,0,0.75))',
            zIndex: 2,
          }}
        />
      </Box>

      {/* Content Container */}
      <Box
        sx={{
          position: 'relative',
          zIndex: 3,
          height: '100%',
          width: '100%',
          px: 2,
          color: 'white',
        }}
      >
        {children}
      </Box>
    </Box>
  );
}
