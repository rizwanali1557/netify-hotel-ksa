"use client";
import { cn } from "../../lib/utils";
import { useEffect, useState } from "react";

interface HeaderProps extends React.HTMLAttributes<HTMLDivElement> {
  logo?: React.ReactNode;
  navigation?: React.ReactNode;
  actions?: React.ReactNode;
  position: "relative" | "fixed" | "sticky";
}

export const Header: React.FC<HeaderProps> = function ({
  className,
  logo,
  navigation,
  actions,
  position,
  ...props
}) {
  const [elevate, setElevate] = useState(false);

  useEffect(() => {
    const handleScroll = () => setElevate(window.scrollY > 40);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div
      className={cn(
        "site-header top-0 w-full z-50 transition-colors duration-200",
        elevate
          ? "bg-white/90 border-b border-gray-200 backdrop-blur"
          : "bg-transparent dark:bg-background/50",
        position,
        className
      )}
      {...props}
    >
      <div className="container flex justify-between items-center py-3">
        <div className="flex items-center gap-6">
          <div>{logo}</div>
          <nav>{navigation}</nav>
        </div>
        <div className="flex items-center gap-3">{actions}</div>
      </div>
    </div>
  );
};
