'use client';

import { useCallback, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import PublicIcon from '@mui/icons-material/Public';
import { MenuItem, Typography, Box, Menu, Button } from '@mui/material';

export function LanguageSelector({
  onChange,
  whiteText = true,
}: {
  onChange?: (locale: string) => unknown;
  whiteText?: boolean;
}) {
  const { i18n } = useTranslation();
  const { language: currentLanguage, options } = i18n;
  const locales = (options.supportedLngs as string[]).filter(
    (locale) => locale.toLowerCase() !== 'cimode',
  );

  const languageNames = useMemo(() => {
    return new Intl.DisplayNames([currentLanguage], { type: 'language' });
  }, [currentLanguage]);

  const [value, setValue] = useState(i18n.language);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const handleOpen = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => setAnchorEl(null);

  const languageChanged = useCallback(
    async (locale: string) => {
      setValue(locale);
      onChange?.(locale);
      await i18n.changeLanguage(locale);
      window.location.reload();
      handleClose();
    },
    [i18n, onChange],
  );

  return (
    <>
      <Button
        onClick={handleOpen}
        startIcon={<PublicIcon sx={{ fontSize: { xs: 16, sm: 18 } }} />}
        sx={{
          textTransform: 'none',
          fontWeight: 500,
          fontSize: { xs: '0.75rem', sm: '0.875rem' },
          color: whiteText ? 'rgba(255,255,255,0.9)' : 'text.primary',
          bgcolor: whiteText ? 'transparent' : 'rgba(0,0,0,0.05)',
          borderRadius: 10,
          px: { xs: 1, sm: 1.5 },
          minWidth: 0,
          transition: 'all 0.2s ease',
          '&:hover': {
            bgcolor: whiteText ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)',
            color: whiteText ? '#ffffff' : 'text.primary',
          },
        }}
      >
        {capitalize(languageNames.of(value) ?? value)}
      </Button>

      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleClose}
        disableScrollLock
        PaperProps={{
          sx: {
            bgcolor: 'rgba(0,0,0,0.85)',
            borderRadius: 2,
            mt: 0.5,
            minWidth: 120,
            boxShadow: '0 4px 12px rgba(0,0,0,0.2)',
          },
        }}
      >
        {locales.map((locale) => (
          <MenuItem
            key={locale}
            onClick={() => languageChanged(locale)}
            sx={{
              fontSize: { xs: '0.75rem', sm: '0.875rem' },
              color: 'rgba(255,255,255,0.9)',
              py: 0.75,
              px: 2,
              transition: 'background-color 0.2s ease',
              '&:hover': {
                bgcolor: 'rgba(255,255,255,0.1)',
              },
              '&.Mui-selected': {
                bgcolor: 'rgba(255,255,255,0.15)',
                '&:hover': {
                  bgcolor: 'rgba(255,255,255,0.2)',
                },
              },
            }}
          >
            {capitalize(languageNames.of(locale) ?? locale)}
          </MenuItem>
        ))}
      </Menu>
    </>
  );
}

function capitalize(lang: string) {
  return lang.charAt(0).toUpperCase() + lang.slice(1);
}