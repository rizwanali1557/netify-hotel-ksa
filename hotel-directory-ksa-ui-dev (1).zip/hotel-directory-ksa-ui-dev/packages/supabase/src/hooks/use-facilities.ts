import { useQuery } from '@tanstack/react-query';
import { useSupabase } from './use-supabase';

export function useFacilities() {
  const client = useSupabase();

  const queryKey = ['supabase:facilities'];

  const queryFn = async () => {
    const { data, error } = await client
      .from('facility')
      .select('*')
      .order('name', { ascending: true });

    if (error) throw error;
    return data ?? [];
  };

  return useQuery({
    queryKey,
    queryFn,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
  });
}