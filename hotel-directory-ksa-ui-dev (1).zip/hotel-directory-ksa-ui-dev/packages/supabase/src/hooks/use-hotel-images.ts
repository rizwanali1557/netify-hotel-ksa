// hooks/use-hotel-details.ts
import { useQuery } from '@tanstack/react-query';
import { useSupabase } from './use-supabase';
import { Database } from '../database.types';

type HotelImage = Pick<
    Database['public']['Tables']['hotel_images']['Row'],
     "id" | "url" | "description"
>;

export function useHotelImages(slug: string) {
  const client = useSupabase();

  return useQuery({
    queryKey: ['hotel-images', slug],
    queryFn: async () => {
      // Fetch hotel details
        // Fetch hotel images
        const { data: images, error: imagesError } = await client
        .from('hotel_images')
        .select('id, url, description')
        .eq('hotel_slug', slug)
        .limit(3)
        .order('sort_order', { ascending: true });
        console.log(images);
        
      if (imagesError) throw imagesError;

      return (images || []) as HotelImage[];
    },
  });
}