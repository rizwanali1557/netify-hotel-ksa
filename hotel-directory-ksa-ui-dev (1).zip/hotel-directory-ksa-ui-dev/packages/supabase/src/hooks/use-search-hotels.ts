'use client';

import { useQuery } from '@tanstack/react-query';
import { useSupabase } from './use-supabase';

export type Hotel = {
  id: string;
  name: string;
  class: number;
  slug: string;
  avg_rating: number | null;
  review_count?: number | null;
  is_best_hotel: boolean;
  min_price: number | null;
  distance_from_haram: number;
  address: string;
  images: { url: string; description: string | null; sort_order: number }[];
  latitude: number;
  longitude: number;
  facilities: { name: string; icon: string | null; slug: string }[];
  promotion?: {
    discount_percent: number;
    valid_from: string;
    valid_to: string;
    is_active: boolean;
  };
};

export type FilterState = {
  stars: string[];
  maxDistance: string;
  minReview: number;
  meals: string[];
  views: string[];
  roomTypes: string[];
  facilities: string[];
};

const queryKeyBase = ['supabase:hotels'];

export function useAvailableHotels(filters: FilterState | null = null) {
  const client = useSupabase();

  const queryKey = [...queryKeyBase, filters ? JSON.stringify(filters) : 'all'];

  const queryFn = async (): Promise<Hotel[]> => {
    let query = client
      .from('hotel')
      .select(`
        id,
        name,
        class,
        slug,
        distance_from_haram,
        serve_breakfast,
        latitude,
        longitude,
        address,
        is_best_hotel,
        hotel_rooms (
          price_per_night,
          city_view,
          room_category_id (
            name,
            slug
          )
        ),
        hotel_images (
          url,
          description,
          sort_order
        ),
        hotel_facility (
          facility:facility_id (
            name,
            icon,
            slug
          )
        ),
        review (
          overall_rating
        ),
        promotion (
          code,
          discount_percent,
          valid_from,
          valid_to,
          is_active
        )
      `)
      .order('sort_order', { referencedTable: 'hotel_images' });

    if (filters) {
      if (filters.stars.length) query = query.in('class', filters.stars.map(Number));
      if (filters.maxDistance && filters.maxDistance !== 'all') {
        query = query.lte('distance_from_haram', Number(filters.maxDistance));
      }
    }

    const { data, error } = await query;

    if (error) throw error;
    if (!data) return [];

    let filteredData = data;

    if (filters) {
      filteredData = data.filter((hotel: any) => {
        // Rating filter
        if (filters.minReview > 0) {
          const avg_rating = hotel.review?.length
            ? hotel.review.reduce((sum: number, r: any) => sum + r.overall_rating, 0) / hotel.review.length
            : 0;
          if (avg_rating < filters.minReview) return false;
        }

        // Meals filter (serve_breakfast is at hotel level)
        if (filters.meals.length) {
          const hasBreakfast = hotel.serve_breakfast;
          if (filters.meals.includes('breakfast') && !hasBreakfast) return false;
          if (filters.meals.includes('no_breakfast') && hasBreakfast) return false;
        }

        // Views filter (city_view is at room level)
        if (filters.views.length && hotel.hotel_rooms?.length) {
          const hasCityView = hotel.hotel_rooms.some((r: any) => r.city_view);
          if (filters.views.includes('city') && !hasCityView) return false;
          if (filters.views.includes('no_city') && hasCityView) return false;
        }

        // Room types filter
        if (filters.roomTypes.length && hotel.hotel_rooms?.length) {
          const hasMatchingRoom = hotel.hotel_rooms.some((r: any) =>
            r.room_category_id?.slug && filters.roomTypes.includes(r.room_category_id.slug)
          );
          if (!hasMatchingRoom) return false;
        }

        // Facilities filter
        if (filters.facilities.length && hotel.hotel_facility?.length) {
          const hotelFacilitySlugs = hotel.hotel_facility.map((hf: any) => hf.facility?.slug);
          const hasAllFacilities = filters.facilities.every((f: string) =>
            hotelFacilitySlugs.includes(f)
          );
          if (!hasAllFacilities) return false;
        }

        return true;
      });
    }

    return filteredData.map((hotel: any) => {
      const min_price = hotel.hotel_rooms?.length
        ? Math.min(...hotel.hotel_rooms.map((r: any) => Number(r.price_per_night || 0)))
        : null;

      const avg_rating = hotel.review?.length
        ? hotel.review.reduce((sum: number, r: any) => sum + (r.overall_rating || 0), 0) / hotel.review.length
        : null;

      // Select the most relevant active promotion (if any)
      const activePromotion = hotel.promotion?.find(
        (p: any) =>
          p.is_active &&
          new Date(p.valid_from) <= new Date() &&
          new Date(p.valid_to) >= new Date()
      );

      return {
        id: hotel.id,
        name: hotel.name,
        class: hotel.class,
        address: hotel.address,
        min_price,
        slug: hotel.slug,
        is_best_hotel: hotel.is_best_hotel,
        latitude: hotel.latitude,
        longitude: hotel.longitude,
        distance_from_haram: hotel.distance_from_haram,
        avg_rating,
        review_count: hotel.review?.length || 0,
        images: hotel.hotel_images || [],
        facilities: hotel.hotel_facility?.map((f: any) => f.facility).filter(Boolean) || [],
        promotion: activePromotion
          ? {
              discount_percent: activePromotion.discount_percent,
              valid_from: activePromotion.valid_from,
              valid_to: activePromotion.valid_to,
              is_active: activePromotion.is_active,
            }
          : undefined,
      };
    });
  };

  return useQuery({
    queryKey,
    queryFn,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
}

export function useHotelCount(filters: FilterState) {
  const client = useSupabase();

  const queryFn = async (): Promise<number> => {
    const needsData = filters.minReview > 0 || filters.meals.length > 0 || filters.views.length > 0 || filters.roomTypes.length > 0 || filters.facilities.length > 0;

    let query = client
      .from('hotel')
      .select(
        needsData
          ? `id, name, class, distance_from_haram, serve_breakfast, review (overall_rating), hotel_rooms (city_view, room_category_id (slug)), hotel_facility (facility:facility_id (slug))`
          : `id`,
        { count: 'exact', head: !needsData }
      );

    if (filters.stars.length) query = query.in('class', filters.stars.map(Number));
    if (filters.maxDistance && filters.maxDistance !== 'all') query = query.lte('distance_from_haram', Number(filters.maxDistance));

    const { data, error, count } = await query;

    if (error) throw error;

    if (!needsData) return count || 0;

    const filteredData = (data || []).filter((hotel: any) => {
      if (filters.minReview > 0) {
        const avg_rating = hotel.review?.length
          ? hotel.review.reduce((sum: number, r: any) => sum + r.overall_rating, 0) / hotel.review.length
          : 0;
        if (avg_rating < filters.minReview) return false;
      }
      if (filters.meals.length) {
        const hasBreakfast = hotel.serve_breakfast;
        if (filters.meals.includes('breakfast') && !hasBreakfast) return false;
        if (filters.meals.includes('no_breakfast') && hasBreakfast) return false;
      }
      if (filters.views.length && hotel.hotel_rooms?.length) {
        const hasCityView = hotel.hotel_rooms.some((r: any) => r.city_view);
        if (filters.views.includes('city') && !hasCityView) return false;
        if (filters.views.includes('no_city') && hasCityView) return false;
      }
      if (filters.roomTypes.length && hotel.hotel_rooms?.length) {
        const hasMatchingRoom = hotel.hotel_rooms.some((r: any) =>
          r.room_category_id?.slug && filters.roomTypes.includes(r.room_category_id.slug)
        );
        if (!hasMatchingRoom) return false;
      }
      if (filters.facilities.length && hotel.hotel_facility?.length) {
        const hotelFacilitySlugs = hotel.hotel_facility.map((hf: any) => hf.facility?.slug);
        const hasAllFacilities = filters.facilities.every((f: string) =>
          hotelFacilitySlugs.includes(f)
        );
        if (!hasAllFacilities) return false;
      }
      return true;
    });

    return filteredData.length;
  };

  return useQuery({
    queryKey: ['supabase:hotel_count', JSON.stringify(filters)],
    queryFn,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
  }).data || 0;
}