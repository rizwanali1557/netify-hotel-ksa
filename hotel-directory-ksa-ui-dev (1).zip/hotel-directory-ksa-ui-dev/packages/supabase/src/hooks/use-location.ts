import { useQuery } from '@tanstack/react-query';
import { useSupabase } from './use-supabase';

type Location = {
  id: string;
  name: string;
  slug: string | null;
  thumbnail: string | null;
};

const queryKey = ['supabase:location'];

export function useLocations() {
  const client = useSupabase();

  const queryFn = async (): Promise<Location[]> => {
    // Fetch all locations
    const { data: locations, error: locationsError } = await client
      .from('location')
      .select('id, name, slug, thumbnail');

    if (locationsError) throw locationsError;
    if (!locations) return [];



    // Map hotel counts into locations
    return locations;
  };

  return useQuery({
    queryKey,
    queryFn,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
}
