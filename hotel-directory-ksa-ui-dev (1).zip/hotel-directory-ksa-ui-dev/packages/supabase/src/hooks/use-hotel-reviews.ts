import { useQuery } from '@tanstack/react-query';
import { useSupabase } from './use-supabase';

type ReviewDetail = {
  id: number;
  service: string;
  rating: number;
};

type Review = {
  id: number;
  reviewer_name: string;
  reviewer_email?: string;
  overall_rating: number;
  feedback: string;
  review_detail_rating: ReviewDetail[];
};

export function useHotelReviews(hotelId?: string) {
  const client = useSupabase();
  const queryKey = ['supabase:hotel-reviews', hotelId];

  const queryFn = async (): Promise<Review[]> => {
    if (!hotelId) return [];

    const { data, error } = await client
      .from('review')
      .select(
        `
        id, reviewer_name, reviewer_email, overall_rating, feedback,
        review_detail_rating(id, service, rating)
      `
      )
      .eq('hotel_id', hotelId);

    if (error) throw error;
    return data as Review[];
  };

  return useQuery({
    queryKey,
    queryFn,
    enabled: !!hotelId,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
  });
}
