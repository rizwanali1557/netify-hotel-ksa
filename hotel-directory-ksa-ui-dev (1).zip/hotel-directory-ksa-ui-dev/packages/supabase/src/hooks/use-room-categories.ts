import { useQuery } from '@tanstack/react-query';
import { useSupabase } from './use-supabase';

export function useRoomCategories() {
  const client = useSupabase();

  const queryKey = ['supabase:room-categories'];

  const queryFn = async () => {
    const { data, error } = await client
      .from('room_category')
      .select('*')
      .order('name', { ascending: true });

    if (error) throw error;
    return data ?? [];
  };

  return useQuery({
    queryKey,
    queryFn,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
  });
}