// hooks/useHotel.ts
import { useQuery } from '@tanstack/react-query';
import { useSupabase } from './use-supabase';
import { Database } from '../database.types';

type Hotel = Database["public"]["Tables"]["hotel"]["Row"];

type HotelImage = {
  url: string;
};

type HotelWithImage = Hotel & {
  image_url: string | null;
};

async function getFirstHotelImage(
  client: any,
  hotelSlug: string
): Promise<HotelImage | null> {
  const { data, error } = await client
    .from('hotel_images')
    .select('url')
    .eq('hotel_slug', hotelSlug)
    .order('sort_order', { ascending: true })
    .limit(1)
    .single();
    console.log(data,error);

  if (error) {
    if (error.code !== 'PGRST116') { // Ignore "No rows found" error
      console.error('Error fetching hotel image:', error);
    }
    return null;
  }

  return data;
}

export function useHotel(hotelSlug: string) {
  const client = useSupabase();

  const queryKey = ['supabase:hotel', hotelSlug];

  const queryFn = async (): Promise<HotelWithImage | null> => {
    if (!hotelSlug) return null;

    // First get the hotel details
    const { data: hotel, error: hotelError } = await client
      .from('hotel')
      .select('*')
      .eq('slug', hotelSlug)
      .eq('is_active', true)
      .single();

    if (hotelError) {
      console.error('Error fetching hotel:', hotelError);
      throw hotelError;
    }

    if (!hotel) return null;

    // Then get the first image
    const image = await getFirstHotelImage(client, hotelSlug);

    return {
      ...hotel,
      image_url: image?.url || null,
    };
  };

  return useQuery({
    queryKey,
    queryFn,
    enabled: !!hotelSlug, // Only run query when hotelSlug is available
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    staleTime: 1000 * 60 * 5, // 5 minutes stale time
  });
}