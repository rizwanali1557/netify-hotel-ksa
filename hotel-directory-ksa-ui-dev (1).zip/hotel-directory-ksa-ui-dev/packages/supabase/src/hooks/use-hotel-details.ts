import { useQuery } from '@tanstack/react-query';
import { useSupabase } from './use-supabase';

type Facility = {
  name: string;
  slug: string;
  icon: string | null;
};

type HotelImage = {
  url: string;
  description: string | null;
  sort_order: number;
};

type Promotion = {
  code: string;
  description: string;
  discount_percent: number;
  valid_from: string;
  valid_to: string;
  is_active: boolean;
};

type HotelDetails = {
  id: string;
  name: string;
  slug: string;
  address: string;
  description: string;
  class: number;
  distance_from_haram: number;
  hotel_images: HotelImage[];
  hotel_facility: { facility: Facility }[];
  promotion?: Promotion;
};

export function useHotelDetails(slug: string) {
  const client = useSupabase();
  const queryKey = ['supabase:hotel-details', slug];

  const queryFn = async (): Promise<HotelDetails | null> => {
    if (!slug) return null;

    const { data, error } = await client
      .from('hotel')
      .select(
        `
        id, name, slug, address, description, class, distance_from_haram,
        hotel_images(url, description, sort_order),
        hotel_facility(facility(name, slug, icon)),
        promotion(code, description, discount_percent, valid_from, valid_to, is_active)
      `
      )
      .eq('slug', slug)
      .maybeSingle();

    if (error) throw error;
    return data as HotelDetails | null;
  };

  return useQuery({
    queryKey,
    queryFn,
    enabled: !!slug,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
  });
}
