import { useQuery } from '@tanstack/react-query';
import { useSupabase } from './use-supabase';
import { Database } from '../database.types';
import { SupabaseClient } from '@supabase/supabase-js';

type BasicHotelInfo = Pick<
  Database['public']['Tables']['hotel']['Row'],
  'id' | 'slug' | 'name' | 'class' | 'address' | 'location_slug'
>;

type HotelImage = {
  url: string;
  description: string | null;
};

type HotelWithImage = BasicHotelInfo & {
  image_url: string | null;
  image_description: string | null;
};

async function getFirstHotelImage(
  client: SupabaseClient<Database>,
  hotelSlug: string
): Promise<HotelImage | null> {
  const { data, error } = await client
    .from('hotel_images')
    .select('url, description')
    .eq('hotel_slug', hotelSlug)
    .order('sort_order', { ascending: true })
    .limit(1)
    .single();

  if (error) {
    if (error.code !== 'PGRST116') { // Ignore "No rows found" error
      console.error('Error fetching hotel image:', error);
    }
    return null;
  }

  return data;
}

export function useAllHotels(
  city_slug: string = "all",
  page: number = 1,
  pageSize: number = 12
) {
  const client = useSupabase();

  const queryKey = ['supabase:all-hotels', city_slug, page];

  const queryFn = async (): Promise<HotelWithImage[]> => {
    // First get the hotels
    let hotelQuery = client
      .from('hotel')
      .select('id, slug, name, class, address, location_slug')
      .eq('is_active', true)
      .order('name', { ascending: true })
      .range((page - 1) * pageSize, page * pageSize - 1);

    if (city_slug && city_slug !== "all") {
      hotelQuery = hotelQuery.eq('location_slug', city_slug);
    }

    const { data: hotels, error: hotelError } = await hotelQuery;
    if (hotelError) throw hotelError;
    if (!hotels) return [];

    // Then get images for each hotel
    const hotelsWithImages = await Promise.all(
      hotels.map(async (hotel) => {
        const image = await getFirstHotelImage(client, hotel.slug || "");
        return {
          ...hotel,
          image_url: image?.url || null,
          image_description: image?.description || null
        };
      })
    );

    return hotelsWithImages;
  };

  return useQuery({
    queryKey,
    queryFn,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
  });
}