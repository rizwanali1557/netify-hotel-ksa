import { useQuery } from '@tanstack/react-query';
import { useSupabase } from './use-supabase';

type RoomImage = { url: string };

type RoomCategory = {
  id: number;
  name: string;
  slug: string;
};

type HotelRoom = {
  id: number;
  hotel_slug: string;
  room_number: string;
  name: string;
  description: string;
  beds: number;
  price_per_night: number;
  status: string;
  city_view: boolean;
  price_per_night_with_breakfast: number | null;
  room_category: RoomCategory;
  room_images: RoomImage[];
};

export function useHotelRooms(slug: string) {
  const client = useSupabase();
  const queryKey = ['supabase:hotel-rooms', slug];

  const queryFn = async (): Promise<HotelRoom[]> => {
    if (!slug) return [];

    const { data, error } = await client
      .from('hotel_rooms')
      .select(
        `
        id, hotel_slug, room_number, name, description, beds,
        price_per_night, status, city_view, price_per_night_with_breakfast,
        room_category(id, name, slug),
        room_images(url)
      `
      )
      .eq('hotel_slug', slug);

    if (error) throw error;
    return data as HotelRoom[];
  };

  return useQuery({
    queryKey,
    queryFn,
    enabled: !!slug,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
  });
}
