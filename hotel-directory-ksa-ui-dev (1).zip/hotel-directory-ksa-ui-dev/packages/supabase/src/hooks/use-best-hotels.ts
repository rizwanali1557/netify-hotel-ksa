"use client";
import { useQuery } from '@tanstack/react-query';
import { useSupabase } from './use-supabase';
import { Database } from '../database.types';
import { SupabaseClient } from '@supabase/supabase-js';

type BasicHotelInfo = Pick<
  Database['public']['Tables']['hotel']['Row'],
  'id' | 'slug' | 'name' | 'class' | 'address' | 'location_slug'
>;

type HotelImage = {
  url: string;
  description: string | null;
};

type ReviewStats = {
  average_rating: number;
  review_count: number;
};

export type HotelWithDetails = BasicHotelInfo & {
  image_url: string | null;
  image_description: string | null;
  review_stats: ReviewStats;
  rank: number;
};

async function getFirstHotelImage(
  client: SupabaseClient<Database>,
  hotelSlug: string
): Promise<HotelImage | null> {
  const { data, error } = await client
    .from('hotel_images')
    .select('url, description')
    .eq('hotel_slug', hotelSlug)
    .order('sort_order', { ascending: true })
    .limit(1)
    .single();

  if (error) {
    if (error.code !== 'PGRST116') {
      console.error('Error fetching hotel image:', error);
    }
    return null;
  }

  return data;
}

async function getHotelReviewStats(
  client: SupabaseClient<Database>,
  hotelId: string
): Promise<ReviewStats> {
  const { data, error } = await client
    .from('review')
    .select('overall_rating')
    .eq('hotel_id', hotelId);

  if (error) {
    console.error('Error fetching reviews:', error);
    return { average_rating: 0, review_count: 0 };
  }

  if (!data || data.length === 0) {
    return { average_rating: 0, review_count: 0 };
  }

  const averageRating = 
    data.reduce((sum, review) => sum + review.overall_rating, 0) / data.length;
  
  return {
    average_rating: parseFloat(averageRating.toFixed(1)),
    review_count: data.length
  };
}

export function useBestHotels() {
  const client = useSupabase();
  const queryKey = ['supabase:top-hotels'];

  const queryFn = async (): Promise<HotelWithDetails[]> => {
    // First get the top hotels ordered by class
    const { data: hotels, error: hotelError } = await client
      .from('hotel')
      .select('id, slug, name, class, address, location_slug')
      .eq('is_active', true)
      .eq('is_best_hotel',true)
      .order('class', { ascending: false })
      .limit(5)

    if (hotelError) throw hotelError;
    if (!hotels) return [];

    // Fetch additional data for each hotel in parallel
    const hotelsWithDetails = await Promise.all(
      hotels.map(async (hotel, index) => {
        const [image, reviewStats] = await Promise.all([
          getFirstHotelImage(client, hotel.slug || ""),
          getHotelReviewStats(client, hotel.id)
        ]);

        return {
          ...hotel,
          image_url: image?.url || null,
          image_description: image?.description || null,
          review_stats: reviewStats,
          rank: index + 1
        };
      })
    );

    return hotelsWithDetails;
  };

  return useQuery({
    queryKey,
    queryFn,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
  });
}