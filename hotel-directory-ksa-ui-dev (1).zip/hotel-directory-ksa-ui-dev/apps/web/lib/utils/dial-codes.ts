export interface Country {
  code: string;
  name: string;
  dialCode: string;
}

export const countries: Country[] = [
  { code: 'SA', name: 'Saudi Arabia', dialCode: '+966' },
  { code: 'US', name: 'United States', dialCode: '+1' },
  { code: 'GB', name: 'United Kingdom', dialCode: '+44' },
  { code: 'AE', name: 'United Arab Emirates', dialCode: '+971' },
  { code: 'IN', name: 'India', dialCode: '+91' },
];