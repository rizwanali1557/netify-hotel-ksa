
export function getFullSupabaseUrl(url:string|null|undefined) : string {
  if (!url) return "";
  if (url.startsWith('http')) return url;
  return `https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public${url}`;
}