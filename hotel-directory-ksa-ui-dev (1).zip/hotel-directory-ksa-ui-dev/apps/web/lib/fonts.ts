import localFont from "next/font/local";

// Local fonts
export const radon = localFont({
  src: [
    {
      path: "../fonts/radon/Radon.otf",
      weight: "400",
      style: "normal",
    },
  ],
  display: "swap",
});

export const fustat = localFont({
  src: [
    {
      path: "../fonts/fustat/Fustat-Light.ttf",
      weight: "400",
      style: "normal",
    },
    {
      path: "../fonts/fustat/Fustat-Medium.ttf",
      weight: "500",
      style: "normal",
    },
    {
      path: "../fonts/fustat/Fustat-SemiBold.ttf",
      weight: "600",
      style: "normal",
    },
     {
      path: "../fonts/fustat/Fustat-Bold.ttf",
      weight: "700",
      style: "normal",
    },
  ],
  display: "swap",
});
