export type testinomial = {
  id: number;
  text: string;
  author: string;
};
export const testimonials :testinomial[]= [
   {
    id: 1,
    text: `We had a rather interesting previous owner to deal with and Justin handled the situation very professionally. We are so happy with our new home. He listened to me when we would tour a house and would make suggestions at looking at other homes based on my feedback from the homes we visited that I didn’t like.
     Very responsive and personable. Would highly recommend him if you are searching for a home!`,
    author: "Amanda Cocilova",
  },
  {
    id: 2,
    text: `We had a rather interesting previous owner to deal with and Justin handled the situation very professionally. We are so happy with our new home. He listened to me when we would tour a house and would make suggestions at looking at other homes based on my feedback from the homes we visited that I didn’t like. Very responsive and personable. Would highly recommend him if you are searching for a home!`,
    author: "Michael Lee",
  },
  {
    id: 3,
    text: `We had a rather interesting previous owner to deal with and Justin handled the situation very professionally. We are so happy with our new home. He listened to me when we would tour a house and would make suggestions at looking at other homes based on my feedback from the homes we visited that I didn’t like. Very responsive and personable. Would highly recommend him if you are searching for a home!`,
    author: "Sarah Johnson",
  },
];
