GRANT USAGE ON SCHEMA public TO anon;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon;
CREATE POLICY "Allow insert all buckets"
ON storage.objects
FOR INSERT
TO anon, authenticated
WITH CHECK (true);
