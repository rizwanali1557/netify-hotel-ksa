INSERT INTO Location (name, thumbnail) VALUES 
('MECCA', 'http://127.0.0.1:54321/storage/v1/object/public/locations//mecca.webp'),
('MEDINA', 'http://127.0.0.1:54321/storage/v1/object/public/locations//medina.webp'),
('RIYADH', 'http://127.0.0.1:54321/storage/v1/object/public/locations//riyadh.webp'),
('JEDDAH', 'http://127.0.0.1:54321/storage/v1/object/public/locations//jeddah.webp');

-- Example facility INSERTs
INSERT INTO facility (name,icon) VALUES
('Elevator','http://127.0.0.1:54321/storage/v1/object/public/facility-icons//elevator-facillity.jpg');

INSERT INTO facility (name) VALUES
('Cards Accepted'),
('Air Conditioner'),
('Wi-Fi Internet'),
('Accessibility'),
('Shuttle Bus Service'),
('Coffee Shop'),
('Restaurant'),
('Fitness Center'),
('Club'),
('Swimming Pool');

-- Hotel: Shurfat Al Talayie Hotel
INSERT INTO hotel (
  id, name, address, distance_from_haram, class, liscense_no,
  description, terms, email, is_best_hotel, latitude,longitude, location_slug, serve_breakfast
)
VALUES (
  '11111111-1111-1111-1111-111111111111',
  'Shurfat Al Talayie Hotel',
  'Ajyad St, Ar Rawabi, Makkah 24234, Saudi Arabia',
  1.4,
  3,
  'LIC-001',
  'Shurfat Al Talayie Hotel is located in Makkah, 1.4 km from Masjid al-Haram. The hotel provides complimentary Wi-Fi and offers free transportation to and from the Haram. All rooms are designed for groups, with quadruple occupancy standard across the property.',
  'Reservations are non-refundable and non-cancellable. Accommodation numbers for weekend stays can be collected between 12:00 PM and 4:00 PM on the same day of check-in. For bookings collected after 4:00 PM, a minimum wait of two hours is required after completing the reservation.',
  'shurfat@example.com',
  true,
  21.4078056,
  39.8185,
  'medina',
  true
);

INSERT INTO hotel_images (
  hotel_slug,url,sort_order
)
VALUES(
  'shurfat-al-talayie-hotel',
  'http://127.0.0.1:54321/storage/v1/object/public/hotel-images//voco-1.jpg',
  1
);
INSERT INTO hotel_images (
  hotel_slug,url
)
VALUES(
  'shurfat-al-talayie-hotel',
  'http://127.0.0.1:54321/storage/v1/object/public/hotel-images//voco-2.jpg'
);
INSERT INTO hotel_images (
  hotel_slug,url
)
VALUES(
  'shurfat-al-talayie-hotel',
  'http://127.0.0.1:54321/storage/v1/object/public/hotel-images//voco-3.jpg'
);
INSERT INTO hotel_images (
  hotel_slug,url
)
VALUES(
  'shurfat-al-talayie-hotel',
  'http://127.0.0.1:54321/storage/v1/object/public/hotel-images//voco-4.jpg'
);



-- Hotel: voco Makkah, an IHG Hotel
INSERT INTO hotel (
  id, name, address, distance_from_haram, class, liscense_no,
  description, terms, email, is_best_hotel,location_slug,serve_breakfast
)
VALUES (
  '22222222-2222-2222-2222-222222222222',
  'voco Makkah, an IHG Hotel',
  'Ibrahim Al Khalil, Misfalah, Makkah 24233, Saudi Arabia',
  1.3,
  4,
  'LIC-002',
  'Modern hotel with IHG quality',
  'IHG guest terms',
  'voco@example.com',
  true,
  'mecca',
  true
);

-- Hotel: Holiday In al Aziziah
INSERT INTO hotel (
  id, name, address, distance_from_haram, class, liscense_no,
  description, terms, email, is_best_hotel,location_slug
)
VALUES (
  '33333333-3333-3333-3333-333333333333',
  'Holiday In al Aziziah',
  'Al Aziziyah District, Makkah 24243, Saudi Arabia',
  3.0,
  4,
  'LIC-003',
  'Premium stay with pool & gym',
  'Holiday Inn terms apply',
  'holidayinn@example.com',
  false,
  'mecca'
);


-- Facilities for Shurfat Al Talayie Hotel (ID: 1111...)
INSERT INTO hotel_facility (hotel_id, facility_id) VALUES
('11111111-1111-1111-1111-111111111111', 1), -- Elevator
('11111111-1111-1111-1111-111111111111', 2), -- Cards Accepted
('11111111-1111-1111-1111-111111111111', 3), -- Air Conditioner
('11111111-1111-1111-1111-111111111111', 4), -- Wi-Fi Internet
('11111111-1111-1111-1111-111111111111', 5), -- Accessibility
('11111111-1111-1111-1111-111111111111', 6); -- Shuttle Bus Service

-- voco Makkah
INSERT INTO hotel_facility (hotel_id, facility_id) VALUES
('22222222-2222-2222-2222-222222222222', 1),
('22222222-2222-2222-2222-222222222222', 3),
('22222222-2222-2222-2222-222222222222', 4),
('22222222-2222-2222-2222-222222222222', 5),
('22222222-2222-2222-2222-222222222222', 7),
('22222222-2222-2222-2222-222222222222', 8),
('22222222-2222-2222-2222-222222222222', 6);

-- Holiday Inn
INSERT INTO hotel_facility (hotel_id, facility_id) VALUES
('33333333-3333-3333-3333-333333333333', 1),
('33333333-3333-3333-3333-333333333333', 2),
('33333333-3333-3333-3333-333333333333', 3),
('33333333-3333-3333-3333-333333333333', 4),
('33333333-3333-3333-3333-333333333333', 5),
('33333333-3333-3333-3333-333333333333', 9), -- Fitness Center
('33333333-3333-3333-3333-333333333333', 11), -- Swimming Pool
('33333333-3333-3333-3333-333333333333', 7);  -- Coffee Shop


INSERT INTO room_category (name) VALUES
('Double'),
('One bedroom suite, living, kitchen and bathroom'),
('Triple'),
('Deluxe Twin'),
('Quad'),
('(King Bed) Double'),
('Elite Studio King Bed'),
('One Bedroom Apartment'),
('Apartment (room and bathroom)'),
('Deluxe King'),
('Quintuple'),
('One Bedroom suite');

-- Additional data ...

-- Additional Hotels
INSERT INTO hotel (
  id, name, address, distance_from_haram, class, liscense_no,
  description, terms, email, is_best_hotel, location_slug
)
VALUES (
  '44444444-4444-4444-4444-444444444444',
  'Swissôtel Al Maqam Makkah',
  'Ibrahim Al Khalil Rd, Makkah 21955, Saudi Arabia',
  0.5,
  5,
  'LIC-004',
  'Luxury hotel with direct Haram view',
  'Premium cancellation policy',
  'swissotel@example.com',
  true,
  'mecca'
),
(
  '55555555-5555-5555-5555-555555555555',
  'Al Marwa Rayhaan by Rotana',
  'King Abdul Aziz Endowment, Makkah 24231, Saudi Arabia',
  0.3,
  4,
  'LIC-005',
  'Comfortable stay with excellent service',
  'Rotana terms and conditions',
  'rayhaan@example.com',
  false,
  'mecca'
);

-- Additional Facilities for new hotels
-- Swissôtel Al Maqam Makkah
INSERT INTO hotel_facility (hotel_id, facility_id) VALUES
('44444444-4444-4444-4444-444444444444', 1),
('44444444-4444-4444-4444-444444444444', 2),
('44444444-4444-4444-4444-444444444444', 3),
('44444444-4444-4444-4444-444444444444', 4),
('44444444-4444-4444-4444-444444444444', 7),
('44444444-4444-4444-4444-444444444444', 8),
('44444444-4444-4444-4444-444444444444', 9),
('44444444-4444-4444-4444-444444444444', 11);

-- Al Marwa Rayhaan by Rotana
INSERT INTO hotel_facility (hotel_id, facility_id) VALUES
('55555555-5555-5555-5555-555555555555', 1),
('55555555-5555-5555-5555-555555555555', 2),
('55555555-5555-5555-5555-555555555555', 3),
('55555555-5555-5555-5555-555555555555', 4),
('55555555-5555-5555-5555-555555555555', 5),
('55555555-5555-5555-5555-555555555555', 7),
('55555555-5555-5555-5555-555555555555', 8);

-- Room categories (if not already inserted)
INSERT INTO room_category (name) VALUES
('Executive Suite'),
('Family Room'),
('Superior Room'),
('Presidential Suite');

-- Rooms for Shurfat Al Talayie Hotel
INSERT INTO hotel_rooms (
  hotel_slug, room_category_id, room_number, name, description, beds, 
  price_per_night, city_view, price_per_night_with_breakfast
) VALUES
('shurfat-al-talayie-hotel', 1, '101', 'Standard Double', 'Comfortable double room with basic amenities', 2, 350.00, true, 400.00),
('shurfat-al-talayie-hotel', 3, '201', 'Triple Room', 'Spacious room with three single beds', 3, 450.00, false, NULL),
('shurfat-al-talayie-hotel', 6, '301', 'King Bed Double', 'Luxury double with king size bed', 2, 550.00, true, 600.00);

-- Rooms for voco Makkah
INSERT INTO hotel_rooms (
  hotel_slug, room_category_id, room_number, name, description, beds, 
  price_per_night, city_view, price_per_night_with_breakfast
) VALUES
('voco-makkah,-an-ihg-hotel', 4, '102', 'Deluxe Twin', 'Two comfortable twin beds with premium amenities', 2, 600.00, true, 650.00),
('voco-makkah,-an-ihg-hotel', 7, '202', 'Elite Studio', 'Studio with king bed and work area', 2, 750.00, true, 800.00),
('voco-makkah,-an-ihg-hotel', 10, '302', 'Deluxe King', 'Spacious room with king bed and sitting area', 2, 850.00, true, 900.00);

-- Rooms for Holiday Inn al Aziziah
INSERT INTO hotel_rooms (
  hotel_slug, room_category_id, room_number, name, description, beds, 
  price_per_night, city_view, price_per_night_with_breakfast
) VALUES
('holiday-in-al-aziziah', 2, '103', 'One Bedroom Suite', 'Suite with separate living area and kitchen', 2, 700.00, false, NULL),
('holiday-in-al-aziziah', 5, '203', 'Quad Room', 'Room with four single beds for groups', 4, 900.00, true, 950.00),
('holiday-in-al-aziziah', 11, '303', 'Quintuple Room', 'Large room with five single beds', 5, 1100.00, false,  1150.00);

-- Rooms for Swissôtel Al Maqam Makkah
INSERT INTO hotel_rooms (
  hotel_slug, room_category_id, room_number, name, description, beds, 
  price_per_night, city_view, price_per_night_with_breakfast
) VALUES
('swissôtel-al-maqam-makkah', 8, '104', 'One Bedroom Apartment', 'Luxury apartment with full amenities', 2, 1200.00, true, 1300.00),
('swissôtel-al-maqam-makkah', 12, '204', 'One Bedroom Suite', 'Premium suite with Haram view', 2, 1500.00, true, 1600.00),
('swissôtel-al-maqam-makkah', 13, '304', 'Executive Suite', 'Exclusive suite with separate living area', 2, 1800.00, true,  1900.00);

-- Rooms for Al Marwa Rayhaan by Rotana
INSERT INTO hotel_rooms (
  hotel_slug, room_category_id, room_number, name, description, beds, 
  price_per_night, city_view,  price_per_night_with_breakfast
) VALUES
('al-marwa-rayhaan-by-rotana', 9, '105', 'Apartment', 'Simple apartment with room and bathroom', 2, 800.00, false,  NULL),
('al-marwa-rayhaan-by-rotana', 14, '205', 'Family Room', 'Spacious room for families', 4, 1000.00, true,  1100.00),
('al-marwa-rayhaan-by-rotana', 15, '305', 'Superior Room', 'Upgraded room with premium features', 2, 900.00, true,  950.00),
('al-marwa-rayhaan-by-rotana', 16, '405', 'Presidential Suite', 'Most luxurious suite in the hotel', 2, 2000.00, true,  2100.00);


INSERT INTO room_images (room_id, url) VALUES
(1, 'http://127.0.0.1:54321/storage/v1/object/public/room-images/room_101.webp'),
(2, 'http://127.0.0.1:54321/storage/v1/object/public/room-images/room_101.webp'),
(3, 'http://127.0.0.1:54321/storage/v1/object/public/room-images/room_101.webp'),
(4, 'http://127.0.0.1:54321/storage/v1/object/public/room-images/room_101.webp'),
(5, 'http://127.0.0.1:54321/storage/v1/object/public/room-images/room_101.webp'),
(6, 'http://127.0.0.1:54321/storage/v1/object/public/room-images/room_101.webp'),
(7, 'http://127.0.0.1:54321/storage/v1/object/public/room-images/room_101.webp'),
(8, 'http://127.0.0.1:54321/storage/v1/object/public/room-images/room_101.webp'),
(9, 'http://127.0.0.1:54321/storage/v1/object/public/room-images/room_101.webp'),
(10, 'http://127.0.0.1:54321/storage/v1/object/public/room-images/room_101.webp'),
(11, 'http://127.0.0.1:54321/storage/v1/object/public/room-images/room_101.webp'),
(12, 'http://127.0.0.1:54321/storage/v1/object/public/room-images/room_101.webp'),
(13, 'http://127.0.0.1:54321/storage/v1/object/public/room-images/room_101.webp'),
(14, 'http://127.0.0.1:54321/storage/v1/object/public/room-images/room_101.webp'),
(16, 'http://127.0.0.1:54321/storage/v1/object/public/room-images/room_101.webp'),
(15, 'http://127.0.0.1:54321/storage/v1/object/public/room-images/room_101.webp');