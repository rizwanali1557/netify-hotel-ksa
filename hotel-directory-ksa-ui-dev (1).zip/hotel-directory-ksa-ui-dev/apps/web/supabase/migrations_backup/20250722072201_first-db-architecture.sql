-- Enable PostGIS extension for spatial data
CREATE EXTENSION IF NOT EXISTS postgis;


-- ENUM TYPES
CREATE TYPE room_status_enum AS ENUM ('AVAILABLE', 'OCCUPIED', 'MAINTENANCE');
CREATE TYPE service_rating_category AS ENUM (
  'CLEANLINESS',
  'STAFF',
  'FOOD',
  'VALUE_FOR_MONEY',
  'COMFORT'
);
CREATE TYPE booking_status_enum AS ENUM ('PENDING', 'CONFIRMED', 'CANCELLED', 'CHECKED_IN', 'COMPLETED');
CREATE TYPE payment_method_enum AS ENUM ('MASTER', 'VISA', 'MADA', 'APPLE_PAY');
CREATE TYPE payment_status_enum AS ENUM ('PENDING', 'COMPLETED', 'FAILED');

CREATE TABLE location (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(100) NOT NULL,
  slug TEXT GENERATED ALWAYS AS (regexp_replace(lower(name), '\s+', '-', 'g')) STORED UNIQUE,
  thumbnail VARCHAR(255)
);


-- HOTEL
CREATE TABLE hotel (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(100) NOT NULL,
  slug TEXT GENERATED ALWAYS AS (regexp_replace(lower(name), '\s+', '-', 'g')) STORED UNIQUE,
  address VARCHAR(255),
  location_slug TEXT REFERENCES location(slug) ON DELETE SET NULL,
  distance_from_haram DECIMAL(10,2),

  -- Add these:
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,

  -- Auto-generate coordinates from lat/lng
  coordinates GEOGRAPHY(POINT, 4326) GENERATED ALWAYS AS (
    ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)
  ) STORED,

  class INT CHECK (class BETWEEN 1 AND 5),
  liscense_no VARCHAR(100) UNIQUE NOT NULL,
  description TEXT NOT NULL,
  terms TEXT NOT NULL,
  serve_breakfast BOOLEAN DEFAULT FALSE,
  payment_policies TEXT,
  land_line VARCHAR(20),
  phone_number VARCHAR(20),
  email VARCHAR(100),
  is_best_hotel BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE
);


-- FACILTIY
CREATE TABLE facility (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) UNIQUE NOT NULL,
  slug TEXT GENERATED ALWAYS AS (regexp_replace(lower(name), '\s+', '-', 'g')) STORED UNIQUE,
  icon VARCHAR(100)
);

CREATE TABLE hotel_facility (
  hotel_id UUID REFERENCES hotel(id) ON DELETE CASCADE,
  facility_id INTEGER REFERENCES facility(id) ON DELETE CASCADE,
  PRIMARY KEY (hotel_id, facility_id)
);


-- ROOM CATEGORY
CREATE TABLE room_category (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  slug TEXT GENERATED ALWAYS AS (regexp_replace(lower(name), '\s+', '-', 'g')) STORED UNIQUE
);


-- ROOM
CREATE TABLE hotel_rooms (
  id SERIAL PRIMARY KEY,
  hotel_slug TEXT NOT NULL REFERENCES hotel(slug) ON DELETE CASCADE,
  room_category_id INTEGER NOT NULL REFERENCES room_category(id),
  room_number VARCHAR(50) NOT NULL,
  name VARCHAR(100),
  description TEXT,
  beds INTEGER DEFAULT 1,
  price_per_night DECIMAL(10,2) NOT NULL,
  status room_status_enum DEFAULT 'AVAILABLE',
  city_view BOOLEAN NOT NULL,
  price_per_night_with_breakfast DECIMAL(10,2),
  UNIQUE (hotel_slug, room_number)
);

-- ROOM IMAGE
CREATE TABLE room_images (
  id SERIAL PRIMARY KEY,
  room_id INTEGER NOT NULL REFERENCES hotel_rooms(id) ON DELETE CASCADE,
  url VARCHAR(255) NOT NULL
);


-- BOOKING
CREATE TABLE booking (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  hotel_slug TEXT NOT NULL REFERENCES hotel(slug),
  room_id INTEGER REFERENCES hotel_rooms(id),
  check_in_date DATE NOT NULL,
  check_out_date DATE NOT NULL,
  nights INTEGER,
  number_of_rooms INTEGER DEFAULT 1,
  booking_status booking_status_enum DEFAULT 'PENDING',
  booking_date DATE DEFAULT CURRENT_DATE,
  promocode VARCHAR(20),
  guest_full_name VARCHAR(100),
  guest_email VARCHAR(100),
  guest_phone VARCHAR(20),
  special_request TEXT,
  gross_total DECIMAL(10,2),
  discount DECIMAL(10,2),
  net_total DECIMAL(10,2),
  account_id UUID REFERENCES accounts(id),
  CHECK (check_out_date > check_in_date)
);


-- BOOKING DETAIL
CREATE TABLE booking_detail (
  id BIGSERIAL PRIMARY KEY,
  booking_id UUID NOT NULL REFERENCES booking(id) ON DELETE CASCADE,
  room_id INTEGER NOT NULL REFERENCES hotel_rooms(id) ON DELETE CASCADE,
  no_of_rooms INTEGER NOT NULL DEFAULT 1,
  room_price DECIMAL(10,2) NOT NULL,
  gross_amount DECIMAL(10,2) NOT NULL,
  discount DECIMAL(10,2) DEFAULT 0,
  net_amount DECIMAL(10,2) NOT NULL
);

-- PAYMENT
CREATE TABLE payment (
  id SERIAL PRIMARY KEY,
  booking_id UUID NOT NULL REFERENCES booking(id),
  amount DECIMAL(10,2) NOT NULL,
  payment_date DATE DEFAULT CURRENT_DATE,
  payment_method payment_method_enum,
  payment_status payment_status_enum DEFAULT 'PENDING'
);


-- PROMOCODE
CREATE TABLE promotion (
  code VARCHAR(20),
  hotel_id UUID REFERENCES hotel(id) ON DELETE CASCADE,
  description TEXT,
  discount_percent DECIMAL(5,2) CHECK (discount_percent BETWEEN 0 AND 100),
  valid_from DATE,
  valid_to DATE,
  is_active BOOLEAN DEFAULT TRUE,
  PRIMARY KEY (code, hotel_id)
);

-- BLOG POST
CREATE TABLE blog_post (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  short_description TEXT,
  long_description TEXT,
  thumbnail VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_by VARCHAR(100),
  tags TEXT[]
);


-- SEARCH LOG
CREATE TABLE search_log (
  id SERIAL PRIMARY KEY,
  location_id UUID REFERENCES location(id) ON DELETE SET NULL,
  check_in_date DATE,
  check_out_date DATE,
  promocode VARCHAR(20),
  search_datetime TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  user_id UUID REFERENCES accounts(id)
);

-- REVIEWS
CREATE TABLE review (
  id SERIAL PRIMARY KEY,
  booking_id UUID NOT NULL REFERENCES booking(id),
  hotel_id UUID REFERENCES hotel(id),
  reviewer_name VARCHAR(100) NOT NULL,
  reviewer_email VARCHAR(100),
  overall_rating INT NOT NULL CHECK (overall_rating BETWEEN 1 AND 5),
  feedback TEXT DEFAULT ''
);

-- REVIEW DETAILS 
CREATE TABLE review_detail_rating (
  id SERIAL PRIMARY KEY,
  review_id INT NOT NULL REFERENCES review(id) ON DELETE CASCADE,
  service service_rating_category NOT NULL,
  rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  UNIQUE (review_id, service)
);


CREATE TABLE hotel_images (
  id SERIAL PRIMARY KEY,
  hotel_slug TEXT NOT NULL REFERENCES hotel(slug) ON DELETE CASCADE,
  url VARCHAR(255) NOT NULL,
  description VARCHAR(255),
  sort_order INTEGER DEFAULT -1
);

-- Create bucket "locations" as public
INSERT INTO storage.buckets (id, name, public)
VALUES ('locations', 'locations', true);

-- Create bucket "hotel-images" as public
INSERT INTO storage.buckets (id, name, public)
VALUES ('hotel-images', 'hotel-images', true);

-- Create bucket "room-images" as public
INSERT INTO storage.buckets (id, name, public)
VALUES ('room-images', 'room-images', true);

-- Create bucket "facility-icons" as public
INSERT INTO storage.buckets (id, name, public)
VALUES ('facility-icons', 'facility-icons', true);

-- Create bucket "blog-images" as public
INSERT INTO storage.buckets (id, name, public)
VALUES ('blog-images', 'blog-images', true);

