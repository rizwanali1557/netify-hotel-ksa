/*
 * -------------------------------------------------------
 * Supabase SaaS Starter Kit Schema
 * This is the schema for the Supabase SaaS Starter Kit.
 * It includes the schema for accounts
 * -------------------------------------------------------
 */
/*
 * -------------------------------------------------------
 * Section: Revoke default privileges from public schema
 * We will revoke all default privileges from public schema on functions to prevent public access to them
 * -------------------------------------------------------
 */
-- Create a private Makerkit schema
create schema if not exists kit;

create extension if not exists "unaccent" schema kit;

-- We remove all default privileges from public schema on functions to
--   prevent public access to them
alter default privileges
    revoke
    execute on functions
    from
    public;

revoke all on schema public
    from
    public;

revoke all PRIVILEGES on database "postgres"
    from
    "anon";

revoke all PRIVILEGES on schema "public"
    from
    "anon";

revoke all PRIVILEGES on schema "storage"
    from
    "anon";

revoke all PRIVILEGES on all SEQUENCES in schema "public"
    from
    "anon";

revoke all PRIVILEGES on all SEQUENCES in schema "storage"
    from
    "anon";

revoke all PRIVILEGES on all FUNCTIONS in schema "public"
    from
    "anon";

revoke all PRIVILEGES on all FUNCTIONS in schema "storage"
    from
    "anon";

revoke all PRIVILEGES on all TABLES in schema "public"
    from
    "anon";

revoke all PRIVILEGES on all TABLES in schema "storage"
    from
    "anon";

-- We remove all default privileges from public schema on functions to
--   prevent public access to them by default
alter default privileges in schema public
    revoke
    execute on functions
    from
    anon,
    authenticated;

-- we allow the authenticated role to execute functions in the public schema
grant usage on schema public to authenticated;

-- we allow the service_role role to execute functions in the public schema
grant usage on schema public to service_role;

/*
 * -------------------------------------------------------
 * Section: Accounts
 * We create the schema for the accounts. Accounts are the top level entity in the Supabase MakerKit. They can be team or personal accounts.
 * -------------------------------------------------------
 */
-- Accounts table
CREATE TABLE IF NOT EXISTS public.accounts (
    id UUID PRIMARY KEY DEFAULT extensions.uuid_generate_v4(),

    -- Name fields
    first_name  VARCHAR(50) NOT NULL,
    last_name   VARCHAR(50) NOT NULL,

    -- Email and phone
    email       VARCHAR(320) UNIQUE,
    phone       VARCHAR(15),

    -- Auth
    password_hash TEXT NOT NULL,

    -- Activity tracking
    registration_date DATE DEFAULT CURRENT_DATE,
    last_login        TIMESTAMP,

    -- Your metadata fields
    picture_url VARCHAR(1000),
    public_data JSONB NOT NULL DEFAULT '{}'::jsonb,

    -- Audit trail
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    created_by UUID REFERENCES auth.users,
    updated_by UUID REFERENCES auth.users
);

comment on table public.accounts is 'Accounts are the top level entity in the Supabase MakerKit';

comment on column public.accounts.first_name is 'The name of the account';
comment on column public.accounts.last_name is 'The name of the account';

comment on column public.accounts.email is 'The email of the account. For teams, this is the email of the team (if any)';

comment on column public.accounts.picture_url is 'The picture url of the account';

comment on column public.accounts.public_data is 'The public data of the account. Use this to store any additional data that you want to store for the account';

comment on column public.accounts.updated_at is 'The timestamp when the account was last updated';

comment on column public.accounts.created_at is 'The timestamp when the account was created';

comment on column public.accounts.created_by is 'The user who created the account';

comment on column public.accounts.updated_by is 'The user who last updated the account';

-- Enable RLS on the accounts table
alter table "public"."accounts"
    enable row level security;

-- SELECT(accounts):
-- Users can read their own accounts
create policy accounts_read on public.accounts for
    select
    to authenticated using (
        (select auth.uid()) = id
    );

-- UPDATE(accounts):
-- Users can update their own accounts
create policy accounts_update on public.accounts
    for update
    to authenticated using (
        (select auth.uid()) = id
    )
    with
    check (
        (select auth.uid()) = id
    );

-- Revoke all on accounts table from authenticated and service_role
revoke all on public.accounts
    from
    authenticated,
    service_role;

-- Open up access to accounts
grant
    select
    ,
    insert,
    update,
    delete on table public.accounts to authenticated,
    service_role;

-- Function "kit.protect_account_fields"
-- Function to protect account fields from being updated by anyone
create
    or replace function kit.protect_account_fields() returns trigger as
$$
begin
    if current_user in ('authenticated', 'anon') then
        if new.id <> old.id or new.email <> old.email then
            raise exception 'You do not have permission to update this field';

        end if;

    end if;

    return NEW;

end
$$ language plpgsql
    set
        search_path = '';

-- trigger to protect account fields
create trigger protect_account_fields
    before
        update
    on public.accounts
    for each row
execute function kit.protect_account_fields();

-- create a trigger to update the account email when the primary owner email is updated
create
    or replace function kit.handle_update_user_email() returns trigger
    language plpgsql
    security definer
    set
        search_path = '' as
$$
begin
    update
        public.accounts
    set email = new.email
    where id = new.id;

    return new;

end;

$$;

-- trigger the function every time a user email is updated only if the user is the primary owner of the account and
-- the account is personal account
create trigger "on_auth_user_updated"
    after
        update of email
    on auth.users
    for each row
execute procedure kit.handle_update_user_email();

-- Function "kit.new_user_created_setup"
-- Setup a new user account after user creation
create
    or replace function kit.new_user_created_setup() returns trigger
    language plpgsql
    security definer
    set
        search_path = '' as
$$
declare
    user_name   text;
    picture_url text;
begin
    if new.raw_user_meta_data ->> 'name' is not null then
        user_name := new.raw_user_meta_data ->> 'name';

    end if;

    if user_name is null and new.email is not null then
        user_name := split_part(new.email, '@', 1);

    end if;

    if user_name is null then
        user_name := '';

    end if;

    if new.raw_user_meta_data ->> 'avatar_url' is not null then
        picture_url := new.raw_user_meta_data ->> 'avatar_url';
    else
        picture_url := null;
    end if;

    insert into public.accounts(id,
                                name,
                                picture_url,
                                email)
    values (new.id,
            user_name,
            picture_url,
            new.email);

    return new;

end;

$$;

-- trigger the function every time a user is created
create trigger on_auth_user_created
    after insert
    on auth.users
    for each row
execute procedure kit.new_user_created_setup();

-- Storage
-- Account Image
insert into storage.buckets (id, name, PUBLIC)
values ('account_image', 'account_image', true);

-- Function: get the storage filename as a UUID.
-- Useful if you want to name files with UUIDs related to an account
create
    or replace function kit.get_storage_filename_as_uuid(name text) returns uuid
    set
        search_path = '' as
$$
begin
    return replace(storage.filename(name), concat('.',
                                                  storage.extension(name)), '')::uuid;

end;

$$ language plpgsql;

grant
    execute on function kit.get_storage_filename_as_uuid (text) to authenticated,
    service_role;

-- RLS policies for storage bucket account_image
create policy account_image on storage.objects for all using (
    bucket_id = 'account_image'
        and (
        kit.get_storage_filename_as_uuid(name) = auth.uid()
        )
    )
    with
    check (
    bucket_id = 'account_image'
        and (
        kit.get_storage_filename_as_uuid(name) = auth.uid()
        )
    );

-- Enable PostGIS extension for spatial data
CREATE EXTENSION IF NOT EXISTS postgis;


-- ENUM TYPES
CREATE TYPE room_status_enum AS ENUM ('AVAILABLE', 'OCCUPIED', 'MAINTENANCE');
CREATE TYPE service_rating_category AS ENUM (
  'CLEANLINESS',
  'STAFF',
  'FOOD',
  'VALUE_FOR_MONEY',
  'COMFORT'
);
CREATE TYPE booking_status_enum AS ENUM ('PENDING', 'CONFIRMED', 'CANCELLED', 'CHECKED_IN', 'COMPLETED');
CREATE TYPE payment_method_enum AS ENUM ('MASTER', 'VISA', 'MADA', 'APPLE_PAY');
CREATE TYPE payment_status_enum AS ENUM ('PENDING', 'COMPLETED', 'FAILED');

CREATE TABLE location (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(100) NOT NULL,
  slug TEXT GENERATED ALWAYS AS (regexp_replace(lower(name), '\s+', '-', 'g')) STORED UNIQUE,
  thumbnail VARCHAR(255)
);


-- HOTEL
CREATE TABLE hotel (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(100) NOT NULL,
  slug TEXT GENERATED ALWAYS AS (regexp_replace(lower(name), '\s+', '-', 'g')) STORED UNIQUE,
  address VARCHAR(255),
  location_slug TEXT REFERENCES location(slug) ON DELETE SET NULL,
  distance_from_haram DECIMAL(10,2),

  -- Add these:
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,

  -- Auto-generate coordinates from lat/lng
  coordinates GEOGRAPHY(POINT, 4326) GENERATED ALWAYS AS (
    ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)
  ) STORED,

  class INT CHECK (class BETWEEN 1 AND 5),
  liscense_no VARCHAR(100) UNIQUE NOT NULL,
  description TEXT NOT NULL,
  terms TEXT NOT NULL,
  serve_breakfast BOOLEAN DEFAULT FALSE,
  payment_policies TEXT,
  land_line VARCHAR(20),
  phone_number VARCHAR(20),
  email VARCHAR(100),
  is_best_hotel BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE
);


-- FACILTIY
CREATE TABLE facility (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) UNIQUE NOT NULL,
  slug TEXT GENERATED ALWAYS AS (regexp_replace(lower(name), '\s+', '-', 'g')) STORED UNIQUE,
  icon VARCHAR(100)
);

CREATE TABLE hotel_facility (
  hotel_id UUID REFERENCES hotel(id) ON DELETE CASCADE,
  facility_id INTEGER REFERENCES facility(id) ON DELETE CASCADE,
  PRIMARY KEY (hotel_id, facility_id)
);


-- ROOM CATEGORY
CREATE TABLE room_category (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  slug TEXT GENERATED ALWAYS AS (regexp_replace(lower(name), '\s+', '-', 'g')) STORED UNIQUE
);


-- ROOM
CREATE TABLE hotel_rooms (
  id SERIAL PRIMARY KEY,
  hotel_slug TEXT NOT NULL REFERENCES hotel(slug) ON DELETE CASCADE,
  room_category_id INTEGER NOT NULL REFERENCES room_category(id),
  room_number VARCHAR(50) NOT NULL,
  name VARCHAR(100),
  description TEXT,
  beds INTEGER DEFAULT 1,
  price_per_night DECIMAL(10,2) NOT NULL,
  status room_status_enum DEFAULT 'AVAILABLE',
  city_view BOOLEAN NOT NULL,
  price_per_night_with_breakfast DECIMAL(10,2),
  UNIQUE (hotel_slug, room_number)
);

-- ROOM IMAGE
CREATE TABLE room_images (
  id SERIAL PRIMARY KEY,
  room_id INTEGER NOT NULL REFERENCES hotel_rooms(id) ON DELETE CASCADE,
  url VARCHAR(255) NOT NULL
);


-- BOOKING
CREATE TABLE booking (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  hotel_slug TEXT NOT NULL REFERENCES hotel(slug),
  room_id INTEGER REFERENCES hotel_rooms(id),
  check_in_date DATE NOT NULL,
  check_out_date DATE NOT NULL,
  nights INTEGER,
  number_of_rooms INTEGER DEFAULT 1,
  booking_status booking_status_enum DEFAULT 'PENDING',
  booking_date DATE DEFAULT CURRENT_DATE,
  promocode VARCHAR(20),
  guest_full_name VARCHAR(100),
  guest_email VARCHAR(100),
  guest_phone VARCHAR(20),
  special_request TEXT,
  gross_total DECIMAL(10,2),
  discount DECIMAL(10,2),
  net_total DECIMAL(10,2),
  account_id UUID REFERENCES accounts(id),
  CHECK (check_out_date > check_in_date)
);


-- BOOKING DETAIL
CREATE TABLE booking_detail (
  id BIGSERIAL PRIMARY KEY,
  booking_id UUID NOT NULL REFERENCES booking(id) ON DELETE CASCADE,
  room_id INTEGER NOT NULL REFERENCES hotel_rooms(id) ON DELETE CASCADE,
  no_of_rooms INTEGER NOT NULL DEFAULT 1,
  room_price DECIMAL(10,2) NOT NULL,
  gross_amount DECIMAL(10,2) NOT NULL,
  discount DECIMAL(10,2) DEFAULT 0,
  net_amount DECIMAL(10,2) NOT NULL
);

-- PAYMENT
CREATE TABLE payment (
  id SERIAL PRIMARY KEY,
  booking_id UUID NOT NULL REFERENCES booking(id),
  amount DECIMAL(10,2) NOT NULL,
  payment_date DATE DEFAULT CURRENT_DATE,
  payment_method payment_method_enum,
  payment_status payment_status_enum DEFAULT 'PENDING'
);


-- PROMOCODE
CREATE TABLE promotion (
  code VARCHAR(20),
  hotel_id UUID REFERENCES hotel(id) ON DELETE CASCADE,
  description TEXT,
  discount_percent DECIMAL(5,2) CHECK (discount_percent BETWEEN 0 AND 100),
  valid_from DATE,
  valid_to DATE,
  is_active BOOLEAN DEFAULT TRUE,
  PRIMARY KEY (code, hotel_id)
);

-- BLOG POST
CREATE TABLE blog_post (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  short_description TEXT,
  long_description TEXT,
  thumbnail VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_by VARCHAR(100),
  tags TEXT[]
);


-- SEARCH LOG
CREATE TABLE search_log (
  id SERIAL PRIMARY KEY,
  location_id UUID REFERENCES location(id) ON DELETE SET NULL,
  check_in_date DATE,
  check_out_date DATE,
  promocode VARCHAR(20),
  search_datetime TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  user_id UUID REFERENCES accounts(id)
);

-- REVIEWS
CREATE TABLE review (
  id SERIAL PRIMARY KEY,
  booking_id UUID NOT NULL REFERENCES booking(id),
  hotel_id UUID REFERENCES hotel(id),
  reviewer_name VARCHAR(100) NOT NULL,
  reviewer_email VARCHAR(100),
  overall_rating INT NOT NULL CHECK (overall_rating BETWEEN 1 AND 5),
  feedback TEXT DEFAULT ''
);

-- REVIEW DETAILS 
CREATE TABLE review_detail_rating (
  id SERIAL PRIMARY KEY,
  review_id INT NOT NULL REFERENCES review(id) ON DELETE CASCADE,
  service service_rating_category NOT NULL,
  rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  UNIQUE (review_id, service)
);


CREATE TABLE hotel_images (
  id SERIAL PRIMARY KEY,
  hotel_slug TEXT NOT NULL REFERENCES hotel(slug) ON DELETE CASCADE,
  url VARCHAR(255) NOT NULL,
  description VARCHAR(255),
  sort_order INTEGER DEFAULT -1
);

-- Create bucket "locations" as public
INSERT INTO storage.buckets (id, name, public)
VALUES ('locations', 'locations', true);

-- Create bucket "hotel-images" as public
INSERT INTO storage.buckets (id, name, public)
VALUES ('hotel-images', 'hotel-images', true);

-- Create bucket "room-images" as public
INSERT INTO storage.buckets (id, name, public)
VALUES ('room-images', 'room-images', true);

-- Create bucket "facility-icons" as public
INSERT INTO storage.buckets (id, name, public)
VALUES ('facility-icons', 'facility-icons', true);

-- Create bucket "blog-images" as public
INSERT INTO storage.buckets (id, name, public)
VALUES ('blog-images', 'blog-images', true);


INSERT INTO Location (name, thumbnail) VALUES 
('MECCA', 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/locations//mecca.webp'),
('MEDINA', 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/locations//medina.webp'),
('RIYADH', 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/locations//riyadh.webp'),
('JEDDAH', 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/locations//jeddah.webp');

-- Example facility INSERTs
INSERT INTO facility (name,icon) VALUES
('Elevator','https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/facility-icons//elevator-facillity.jpg');

INSERT INTO facility (name) VALUES
('Cards Accepted'),
('Air Conditioner'),
('Wi-Fi Internet'),
('Accessibility'),
('Shuttle Bus Service'),
('Coffee Shop'),
('Restaurant'),
('Fitness Center'),
('Club'),
('Swimming Pool');

-- Hotel: Shurfat Al Talayie Hotel
INSERT INTO hotel (
  id, name, address, distance_from_haram, class, liscense_no,
  description, terms, email, is_best_hotel, latitude,longitude, location_slug, serve_breakfast
)
VALUES (
  '11111111-1111-1111-1111-111111111111',
  'Shurfat Al Talayie Hotel',
  'Ajyad St, Ar Rawabi, Makkah 24234, Saudi Arabia',
  1.4,
  3,
  'LIC-001',
  'Shurfat Al Talayie Hotel is located in Makkah, 1.4 km from Masjid al-Haram. The hotel provides complimentary Wi-Fi and offers free transportation to and from the Haram. All rooms are designed for groups, with quadruple occupancy standard across the property.',
  'Reservations are non-refundable and non-cancellable. Accommodation numbers for weekend stays can be collected between 12:00 PM and 4:00 PM on the same day of check-in. For bookings collected after 4:00 PM, a minimum wait of two hours is required after completing the reservation.',
  'shurfat@example.com',
  true,
  21.4078056,
  39.8185,
  'medina',
  true
);

INSERT INTO hotel_images (
  hotel_slug,url,sort_order
)
VALUES(
  'shurfat-al-talayie-hotel',
  'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/hotel-images//voco-1.jpg',
  1
);
INSERT INTO hotel_images (
  hotel_slug,url
)
VALUES(
  'shurfat-al-talayie-hotel',
  'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/hotel-images//voco-2.jpg'
);
INSERT INTO hotel_images (
  hotel_slug,url
)
VALUES(
  'shurfat-al-talayie-hotel',
  'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/hotel-images//voco-3.jpg'
);
INSERT INTO hotel_images (
  hotel_slug,url
)
VALUES(
  'shurfat-al-talayie-hotel',
  'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/hotel-images//voco-4.jpg'
);



-- Hotel: voco Makkah, an IHG Hotel
INSERT INTO hotel (
  id, name, address, distance_from_haram, class, liscense_no,
  description, terms, email, is_best_hotel,location_slug,serve_breakfast
)
VALUES (
  '22222222-2222-2222-2222-222222222222',
  'voco Makkah, an IHG Hotel',
  'Ibrahim Al Khalil, Misfalah, Makkah 24233, Saudi Arabia',
  1.3,
  4,
  'LIC-002',
  'Modern hotel with IHG quality',
  'IHG guest terms',
  'voco@example.com',
  true,
  'mecca',
  true
);

-- Hotel: Holiday In al Aziziah
INSERT INTO hotel (
  id, name, address, distance_from_haram, class, liscense_no,
  description, terms, email, is_best_hotel,location_slug
)
VALUES (
  '33333333-3333-3333-3333-333333333333',
  'Holiday In al Aziziah',
  'Al Aziziyah District, Makkah 24243, Saudi Arabia',
  3.0,
  4,
  'LIC-003',
  'Premium stay with pool & gym',
  'Holiday Inn terms apply',
  'holidayinn@example.com',
  false,
  'mecca'
);


-- Facilities for Shurfat Al Talayie Hotel (ID: 1111...)
INSERT INTO hotel_facility (hotel_id, facility_id) VALUES
('11111111-1111-1111-1111-111111111111', 1), -- Elevator
('11111111-1111-1111-1111-111111111111', 2), -- Cards Accepted
('11111111-1111-1111-1111-111111111111', 3), -- Air Conditioner
('11111111-1111-1111-1111-111111111111', 4), -- Wi-Fi Internet
('11111111-1111-1111-1111-111111111111', 5), -- Accessibility
('11111111-1111-1111-1111-111111111111', 6); -- Shuttle Bus Service

-- voco Makkah
INSERT INTO hotel_facility (hotel_id, facility_id) VALUES
('22222222-2222-2222-2222-222222222222', 1),
('22222222-2222-2222-2222-222222222222', 3),
('22222222-2222-2222-2222-222222222222', 4),
('22222222-2222-2222-2222-222222222222', 5),
('22222222-2222-2222-2222-222222222222', 7),
('22222222-2222-2222-2222-222222222222', 8),
('22222222-2222-2222-2222-222222222222', 6);

-- Holiday Inn
INSERT INTO hotel_facility (hotel_id, facility_id) VALUES
('33333333-3333-3333-3333-333333333333', 1),
('33333333-3333-3333-3333-333333333333', 2),
('33333333-3333-3333-3333-333333333333', 3),
('33333333-3333-3333-3333-333333333333', 4),
('33333333-3333-3333-3333-333333333333', 5),
('33333333-3333-3333-3333-333333333333', 9), -- Fitness Center
('33333333-3333-3333-3333-333333333333', 11), -- Swimming Pool
('33333333-3333-3333-3333-333333333333', 7);  -- Coffee Shop


INSERT INTO room_category (name) VALUES
('Double'),
('One bedroom suite, living, kitchen and bathroom'),
('Triple'),
('Deluxe Twin'),
('Quad'),
('(King Bed) Double'),
('Elite Studio King Bed'),
('One Bedroom Apartment'),
('Apartment (room and bathroom)'),
('Deluxe King'),
('Quintuple'),
('One Bedroom suite');

-- Additional data ...

-- Additional Hotels
INSERT INTO hotel (
  id, name, address, distance_from_haram, class, liscense_no,
  description, terms, email, is_best_hotel, location_slug
)
VALUES (
  '44444444-4444-4444-4444-444444444444',
  'Swissôtel Al Maqam Makkah',
  'Ibrahim Al Khalil Rd, Makkah 21955, Saudi Arabia',
  0.5,
  5,
  'LIC-004',
  'Luxury hotel with direct Haram view',
  'Premium cancellation policy',
  'swissotel@example.com',
  true,
  'mecca'
),
(
  '55555555-5555-5555-5555-555555555555',
  'Al Marwa Rayhaan by Rotana',
  'King Abdul Aziz Endowment, Makkah 24231, Saudi Arabia',
  0.3,
  4,
  'LIC-005',
  'Comfortable stay with excellent service',
  'Rotana terms and conditions',
  'rayhaan@example.com',
  false,
  'mecca'
);

-- Additional Facilities for new hotels
-- Swissôtel Al Maqam Makkah
INSERT INTO hotel_facility (hotel_id, facility_id) VALUES
('44444444-4444-4444-4444-444444444444', 1),
('44444444-4444-4444-4444-444444444444', 2),
('44444444-4444-4444-4444-444444444444', 3),
('44444444-4444-4444-4444-444444444444', 4),
('44444444-4444-4444-4444-444444444444', 7),
('44444444-4444-4444-4444-444444444444', 8),
('44444444-4444-4444-4444-444444444444', 9),
('44444444-4444-4444-4444-444444444444', 11);

-- Al Marwa Rayhaan by Rotana
INSERT INTO hotel_facility (hotel_id, facility_id) VALUES
('55555555-5555-5555-5555-555555555555', 1),
('55555555-5555-5555-5555-555555555555', 2),
('55555555-5555-5555-5555-555555555555', 3),
('55555555-5555-5555-5555-555555555555', 4),
('55555555-5555-5555-5555-555555555555', 5),
('55555555-5555-5555-5555-555555555555', 7),
('55555555-5555-5555-5555-555555555555', 8);

-- Room categories (if not already inserted)
INSERT INTO room_category (name) VALUES
('Executive Suite'),
('Family Room'),
('Superior Room'),
('Presidential Suite');

-- Rooms for Shurfat Al Talayie Hotel
INSERT INTO hotel_rooms (
  hotel_slug, room_category_id, room_number, name, description, beds, 
  price_per_night, city_view, price_per_night_with_breakfast
) VALUES
('shurfat-al-talayie-hotel', 1, '101', 'Standard Double', 'Comfortable double room with basic amenities', 2, 350.00, true, 400.00),
('shurfat-al-talayie-hotel', 3, '201', 'Triple Room', 'Spacious room with three single beds', 3, 450.00, false, NULL),
('shurfat-al-talayie-hotel', 6, '301', 'King Bed Double', 'Luxury double with king size bed', 2, 550.00, true, 600.00);

-- Rooms for voco Makkah
INSERT INTO hotel_rooms (
  hotel_slug, room_category_id, room_number, name, description, beds, 
  price_per_night, city_view, price_per_night_with_breakfast
) VALUES
('voco-makkah,-an-ihg-hotel', 4, '102', 'Deluxe Twin', 'Two comfortable twin beds with premium amenities', 2, 600.00, true, 650.00),
('voco-makkah,-an-ihg-hotel', 7, '202', 'Elite Studio', 'Studio with king bed and work area', 2, 750.00, true, 800.00),
('voco-makkah,-an-ihg-hotel', 10, '302', 'Deluxe King', 'Spacious room with king bed and sitting area', 2, 850.00, true, 900.00);

-- Rooms for Holiday Inn al Aziziah
INSERT INTO hotel_rooms (
  hotel_slug, room_category_id, room_number, name, description, beds, 
  price_per_night, city_view, price_per_night_with_breakfast
) VALUES
('holiday-in-al-aziziah', 2, '103', 'One Bedroom Suite', 'Suite with separate living area and kitchen', 2, 700.00, false, NULL),
('holiday-in-al-aziziah', 5, '203', 'Quad Room', 'Room with four single beds for groups', 4, 900.00, true, 950.00),
('holiday-in-al-aziziah', 11, '303', 'Quintuple Room', 'Large room with five single beds', 5, 1100.00, false,  1150.00);

-- Rooms for Swissôtel Al Maqam Makkah
INSERT INTO hotel_rooms (
  hotel_slug, room_category_id, room_number, name, description, beds, 
  price_per_night, city_view, price_per_night_with_breakfast
) VALUES
('swissôtel-al-maqam-makkah', 8, '104', 'One Bedroom Apartment', 'Luxury apartment with full amenities', 2, 1200.00, true, 1300.00),
('swissôtel-al-maqam-makkah', 12, '204', 'One Bedroom Suite', 'Premium suite with Haram view', 2, 1500.00, true, 1600.00),
('swissôtel-al-maqam-makkah', 13, '304', 'Executive Suite', 'Exclusive suite with separate living area', 2, 1800.00, true,  1900.00);

-- Rooms for Al Marwa Rayhaan by Rotana
INSERT INTO hotel_rooms (
  hotel_slug, room_category_id, room_number, name, description, beds, 
  price_per_night, city_view,  price_per_night_with_breakfast
) VALUES
('al-marwa-rayhaan-by-rotana', 9, '105', 'Apartment', 'Simple apartment with room and bathroom', 2, 800.00, false,  NULL),
('al-marwa-rayhaan-by-rotana', 14, '205', 'Family Room', 'Spacious room for families', 4, 1000.00, true,  1100.00),
('al-marwa-rayhaan-by-rotana', 15, '305', 'Superior Room', 'Upgraded room with premium features', 2, 900.00, true,  950.00),
('al-marwa-rayhaan-by-rotana', 16, '405', 'Presidential Suite', 'Most luxurious suite in the hotel', 2, 2000.00, true,  2100.00);


INSERT INTO room_images (room_id, url) VALUES
(1, 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/room-images/room_101.webp'),
(2, 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/room-images/room_101.webp'),
(3, 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/room-images/room_101.webp'),
(4, 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/room-images/room_101.webp'),
(5, 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/room-images/room_101.webp'),
(6, 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/room-images/room_101.webp'),
(7, 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/room-images/room_101.webp'),
(8, 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/room-images/room_101.webp'),
(9, 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/room-images/room_101.webp'),
(10, 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/room-images/room_101.webp'),
(11, 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/room-images/room_101.webp'),
(12, 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/room-images/room_101.webp'),
(13, 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/room-images/room_101.webp'),
(14, 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/room-images/room_101.webp'),
(16, 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/room-images/room_101.webp'),
(15, 'https://igxhrxoutpqnotszivhm.supabase.co/storage/v1/object/public/room-images/room_101.webp');

GRANT USAGE ON SCHEMA public TO anon;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon;
CREATE POLICY "Allow insert all buckets"
ON storage.objects
FOR INSERT
TO anon, authenticated
WITH CHECK (true);
