"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Box,
  Typography,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
} from "@mui/material";
import { useState } from "react";
import { Menu as MenuIcon, Home, Hotel, LocalOffer } from "@mui/icons-material";

// ✅ scalable config
const NAV_LINKS = [
  { label: "Home", href: "/", icon: <Home fontSize="small" /> },
  { label: "Hotels", href: "/hotels", icon: <Hotel fontSize="small" /> },
  { label: "Promo Code", href: "/promo-code", icon: <LocalOffer fontSize="small" /> },
];

export function SiteNavigation() {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  const isActive = (path: string) =>
    pathname === path || (path !== "/" && pathname.startsWith(path));

  const toggleDrawer = (open: boolean) => () => {
    setMobileOpen(open);
  };

  return (
    <>
      {/* Desktop nav */}
      <Box
        sx={{
          display: { xs: "none", md: "flex" },
          alignItems: "center",
          gap: 4,
        }}
      >
        {NAV_LINKS.map((item) => {
          const active = isActive(item.href);
          return (
            <Box
              key={item.href}
              component={Link}
              href={item.href}
              sx={{
                position: "relative",
                display: "flex",
                alignItems: "center",
                gap: 0.75,
                fontSize: "0.95rem",
                fontWeight: active ? 600 : 400,
                color: active ? "primary.main" : "text.primary",
                textDecoration: "none",
                "&:after": {
                  content: '""',
                  position: "absolute",
                  bottom: -2,
                  left: 0,
                  width: active ? "100%" : 0,
                  height: "1.5px",
                  backgroundColor: "primary.main",
                  transition: "width 0.25s ease",
                },
                "&:hover:after": {
                  width: "100%",
                },
              }}
            >
              {item.icon}
              <Typography component="span">{item.label}</Typography>
            </Box>
          );
        })}
      </Box>

      {/* Mobile nav */}
      <Box sx={{ display: { xs: "flex", md: "none" } }}>
        <IconButton onClick={toggleDrawer(true)} size="large">
          <MenuIcon />
        </IconButton>
        <Drawer anchor="right" open={mobileOpen} onClose={toggleDrawer(false)}>
          <Box sx={{ width: 240 }} role="presentation" onClick={toggleDrawer(false)}>
            <List>
              {NAV_LINKS.map((item) => {
                const active = isActive(item.href);
                return (
                  <ListItem key={item.href} disablePadding>
                    <ListItemButton
                      component={Link}
                      href={item.href}
                      selected={active}
                      sx={{
                        "&.Mui-selected": {
                          color: "primary.main",
                          backgroundColor: "transparent",
                          fontWeight: 600,
                        },
                      }}
                    >
                      <ListItemIcon sx={{ minWidth: 36 }}>{item.icon}</ListItemIcon>
                      <ListItemText primary={item.label} />
                    </ListItemButton>
                  </ListItem>
                );
              })}
            </List>
          </Box>
        </Drawer>
      </Box>
    </>
  );
}
