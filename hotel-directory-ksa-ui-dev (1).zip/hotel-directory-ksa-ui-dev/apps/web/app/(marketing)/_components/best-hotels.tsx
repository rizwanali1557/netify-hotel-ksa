'use client';
import { useRef } from 'react';
import {
  Box,
  Button,
  Container,
  Typography,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import { useBestHotels } from '@kit/supabase/hooks/use-best-hotels';
import { CompactHotelCard } from '~/components/hotel-card';
import {radon,fustat } from '~/lib/fonts';
const BestHotelsSection = () => {
  const theme = useTheme();
  const { data: hotels, error } = useBestHotels();
  const scrollRef = useRef<HTMLDivElement>(null);

  if (error) return <Typography color="error">Error loading hotels</Typography>;


  return (
    <Box sx={{position:'relative',maxWidth:'100dvw',overflow:'hidden',bgcolor:'#f5f5f5'}}>
      <Box
        component="img"
        src="/images/pattern-image.svg"
        alt="Pattern Decoration"
        sx={{
          position: 'absolute',
          bottom: '0',
          left: '0',
          width: '30%',
          height: '30%',
          objectFit: 'none',
          zIndex: 0, // Behind content
        }}
      />
    
    <Container maxWidth="xl" sx={{py:8,}}>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          mb: 2,
        }}
      >
        <Box>
          <Typography
            variant="h2"
            sx={{
              fontWeight: 700,
              color: theme.palette.primary.main,
              fontFamily: radon.style.fontFamily,
            }}
          >
            Best Hotels
          </Typography>
          <Typography
            variant="subtitle1"
            sx={{ color: theme.palette.text.secondary,
               fontFamily: fustat.style.fontFamily,
               fontWeight: 500
             }}
          >
            Try One Of These Highly-Rated Premium Hotels
          </Typography>
        </Box>
        <Button
          href='/contact-us'
          variant="contained"
          color="success"
          sx={{ textTransform: 'none', borderRadius: '25px', px: 3, py: 1 }}
        >
          Contact Us
        </Button>
      </Box>

      {/* Horizontal Scroll */}
      <Box sx={{ position: 'relative' }}>

        {/* Hotel Cards Container */}
        <Box
          ref={scrollRef}
          sx={{
            display: 'flex',
            overflowX: 'auto',
            gap: 2,
            scrollBehavior: 'smooth',
            '&::-webkit-scrollbar': { display: 'none' },
            py: 2,
          }}
        >
          {hotels?.map((hotel) => (
            <CompactHotelCard key={hotel.name} hotel={hotel} />
          ))}
        </Box>
      </Box>
    </Container>
    </Box>
  );
};

export default BestHotelsSection;
