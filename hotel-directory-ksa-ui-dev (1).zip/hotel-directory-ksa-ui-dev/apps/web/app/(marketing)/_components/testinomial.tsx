'use client';
import { useState } from 'react';
import Image from 'next/image';
import {
  Box,
  Button,
  Container,
  LinearProgress,
  Typography,
} from '@mui/material';
import { AnimatePresence, motion } from 'framer-motion';
import { fustat, radon } from '~/lib/fonts';
import { testimonials } from '../../../utilsdata/testinomial';

const Testimonial = () => {
  const [index, setIndex] = useState(0);

  const nextSlide = () => setIndex((prev) => (prev + 1) % testimonials.length);
  const prevSlide = () =>
    setIndex((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1));

  const currentTestimonial = testimonials[index];
  const progressWidth = ((index + 1) / testimonials.length) * 100;

  if (!currentTestimonial) return null;

  return (
    <Box sx={{ position: 'relative', marginBottom: 10 }}>
      <Box sx={{ position: 'absolute', bottom: '-15%', left: 0 }}>
        <Image
          src="/images/bottomcardimg.png"
          alt="Hotel 2"
          width={460}
          height={460}
        />
      </Box>
      <Container
        maxWidth="xl"
        sx={{
          mt: 10,
          position: 'relative',
          px: { xs: 2, sm: 3, md: 6, lg: 12, xl: 12 },
        }}
      >
        {/* Title */}
        <Typography
          variant="h2"
          sx={{
            fontSize: { xs: '40px', md: '68px' },
            fontWeight: '700',
            color: '#4D8A68',
            mb: 4,
            fontFamily: radon.style.fontFamily,
          }}
        >
          What Our Client Says
        </Typography>

        <Box
          display="grid"
          gridTemplateColumns={{ xs: '1fr', md: '1fr 2fr' }}
          gap={5}
          alignItems="stretch"
        >
          <Box
            display="flex"
            flexDirection="column"
            justifyContent="space-between"
            height="100%"
          >
            <Box display="flex" justifyContent="flex-end">
              <Image
                src="/images/qoute.png"
                alt="Quote"
                width={111}
                height={90}
                style={{ objectFit: 'contain' }}
              />
            </Box>

            <Box
              display="flex"
              gap={2}
              mt={2}
              justifyContent="flex-start"
              alignItems="center"
            >
              <Button onClick={prevSlide} sx={{ minWidth: 0, p: 0 }}>
                <svg
                  width="31"
                  height="31"
                  viewBox="0 0 31 31"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M28.4165 15.5H10.8214"
                    stroke="#4D8A68"
                    strokeWidth="1.5"
                    strokeLinecap="square"
                  />
                  <path
                    d="M12.8442 22.3405L2.58324 15.4998L12.8442 8.65918L10.5632 15.4998L12.8442 22.3405Z"
                    fill="#4D8A68"
                    stroke="#4D8A68"
                    strokeWidth="1.5"
                    strokeLinecap="square"
                  />
                </svg>
              </Button>

              <Button onClick={nextSlide} sx={{ minWidth: 0, p: 0 }}>
                <svg
                  width="31"
                  height="31"
                  viewBox="0 0 31 31"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M2.5835 15.5H20.1786"
                    stroke="#4D8A68"
                    strokeWidth="1.5"
                    strokeLinecap="square"
                  />
                  <path
                    d="M18.1558 22.3405L28.4168 15.4998L18.1558 8.65918L20.4368 15.4998L18.1558 22.3405Z"
                    fill="#4D8A68"
                    stroke="#4D8A68"
                    strokeWidth="1.5"
                    strokeLinecap="square"
                  />
                </svg>
              </Button>
            </Box>
          </Box>

          <Box sx={{ flex: 1, position: 'relative' }}>
            <AnimatePresence mode="wait">
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.5 }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    fontSize: { xs: 20, md: 28 },
                    color: '#231F20',
                    mb: 2,
                    fontFamily: radon.style.fontFamily,
                  }}
                >
                  {currentTestimonial.text}
                </Typography>

                <Typography
                  variant="h5"
                  sx={{
                    fontSize: { xs: 24, md: 30 },
                    fontWeight: 'bold',
                    color: '#4D8A68',
                    mt: 3,
                    fontFamily: fustat.style.fontFamily,
                  }}
                >
                  {currentTestimonial.author}
                </Typography>

                {/* Progress Bar */}
                <Box sx={{ mt: 4 }}>
                  <LinearProgress
                    variant="determinate"
                    value={progressWidth}
                    sx={{
                      height: 4,
                      borderRadius: 2,
                      backgroundColor: '#E0E0E0',
                      '& .MuiLinearProgress-bar': {
                        backgroundColor: '#4D8A68',
                      },
                    }}
                  />
                </Box>
              </motion.div>
            </AnimatePresence>
          </Box>
        </Box>
      </Container>
    </Box>
  );
};

export default Testimonial;
