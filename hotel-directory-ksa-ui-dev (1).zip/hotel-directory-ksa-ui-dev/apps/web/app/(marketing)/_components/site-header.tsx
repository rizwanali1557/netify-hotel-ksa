'use client';

import { useState } from 'react';

import { usePathname } from 'next/navigation';

import MenuIcon from '@mui/icons-material/Menu';
import {
  Box,
  Button,
  Container,
  Divider,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemText,
  Toolbar,
} from '@mui/material';

import { LanguageSelector } from '@kit/ui/language-selector';

import { AppLogo } from '~/components/app-logo';

interface SiteHeaderProps {
  position?: 'fixed' | 'sticky' | 'relative';
}

export function SiteHeader({ position = 'relative' }: SiteHeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const pathname = usePathname();

  const navItems = [
    { name: 'Home', href: '/' },
    { name: 'Hotels', href: '/hotels' },
    { name: 'Blog', href: '/blog' },
    { name: 'About Us', href: '/aboutus' },
    { name: 'Reviews', href: '/reviews' },
    { name: 'Call Us', href: '/callus' },
  ];

  const isActive = (href: string) => {
    if (href === '/') return pathname === '/';
    return pathname.startsWith(href);
  };

  return (
    <>
      <Box
        position={position}
        sx={{
          backgroundColor: 'transparent',
          backdropFilter: 'none',
          width: '100%',
          top: 0,
          paddingTop:2,
        }}
      >
        <Container maxWidth="xl" sx={{ px: { xs: 2, md: 4 } }}>
          <Toolbar
            disableGutters
            sx={{ display: 'flex', alignItems: 'flex-end' }}
          >
            {/* Left - Logo (outside the bordered box) */}
            <Box
              sx={{
                display: 'flex',
                width: '200px',
                alignItems: 'flex-end',
                justifyContent: 'center',
                pb: 0,
              }}
            >
              <AppLogo size={200} />
            </Box>
            {/* Combined Nav and Side Actions with single border bottom */}
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'flex-end',
                gap: { xs: 1, md: 4 },
                borderBottom: '2px solid rgba(255, 255, 255, 0.3)',
                py: 2,
                flex: 1,
                ml: { md: 4 },
              }}
            >
              {/* Center - Desktop Nav */}
              <Box
                sx={{
                  display: { xs: 'none', md: 'flex' },
                  flex: 1,
                  justifyContent: 'center',
                  gap: 3,
                }}
              >
                {navItems.map((item) => (
                  <Button
                    key={item.name}
                    href={item.href}
                    aria-label={`Go to ${item.name}`}
                    sx={{
                      color: isActive(item.href)
                        ? 'white'
                        : 'rgba(255, 255, 255, 0.8)',
                      fontWeight: 500,
                      borderRadius: 0,
                      px: 2,
                      backgroundColor: isActive(item.href)
                        ? 'rgba(255,255,255,0.1)'
                        : 'transparent',
                      backdropFilter: isActive(item.href)
                        ? 'blur(12px)'
                        : 'blur(0px)',
                      border: `1px solid rgba(255,255,255,${isActive(item.href) ? 0.3 : 0})`,
                      '&:hover': {
                        color: 'white',
                        backgroundColor: 'rgba(255,255,255,0.15)',
                        backdropFilter: 'blur(12px)',
                        borderRadius: 0,
                      },
                    }}
                  >
                    {item.name}
                  </Button>
                ))}
              </Box>

              {/* Right - Language + Login + Mobile Menu */}
              <Box
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'end',
                  gap: 1,
                }}
              >
                <LanguageSelector whiteText />

                {/* Glassy Login */}
                <Button
                  variant="outlined"
                  href="/login"
                  sx={{
                    color: 'white',
                    borderRadius: 20,
                    px: 3,
                    backgroundColor: 'rgba(255, 255, 255, 0.1)',
                    border: '1px solid rgba(255, 255, 255, 0.3)',
                    backdropFilter: 'blur(12px)',
                    '&:hover': {
                      backgroundColor: 'rgba(255, 255, 255, 0.2)',
                      borderColor: 'white',
                    },
                  }}
                >
                  Login
                </Button>

                {/* Mobile toggle */}
                <IconButton
                  size="large"
                  aria-label="open menu"
                  onClick={() => setMobileMenuOpen(true)}
                  sx={{
                    display: { md: 'none' },
                    color: 'white',
                    '&:hover': { backgroundColor: 'rgba(255,255,255,0.1)' },
                  }}
                >
                  <MenuIcon />
                </IconButton>
              </Box>
            </Box>
          </Toolbar>
        </Container>
      </Box>

      {/* Mobile Drawer */}
      <Drawer
        disableScrollLock
        anchor="left"
        open={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
        sx={{
          '& .MuiDrawer-paper': {
            backgroundColor: 'rgba(0, 0, 0, 0.9)',
            backdropFilter: 'blur(12px)',
            color: 'white',
            width: 280,
          },
        }}
      >
        <Box sx={{ p: 2 }}>
          {/* Drawer Header */}
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              mb: 2,
              bgcolor: 'red',
            }}
          >
            <AppLogo />
          </Box>

          <Divider sx={{ borderColor: 'rgba(255, 255, 255, 0.1)', mb: 2 }} />

          {/* Drawer Nav */}
          <List>
            {navItems.map((item) => (
              <ListItem
                key={item.name}
                component="a"
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                sx={{
                  color: isActive(item.href)
                    ? 'white'
                    : 'rgba(255, 255, 255, 0.8)',
                  backgroundColor: isActive(item.href)
                    ? 'rgba(255,255,255,0.1)'
                    : 'transparent',
                  borderRadius: 1,
                  mb: 0.5,
                  '&:hover': {
                    color: 'white',
                    backgroundColor: 'rgba(255,255,255,0.15)',
                  },
                }}
              >
                <ListItemText primary={item.name} />
              </ListItem>
            ))}
          </List>

          <Divider sx={{ borderColor: 'rgba(255, 255, 255, 0.1)', my: 2 }} />

          {/* Glassy Login inside Drawer too */}
          <Button
            variant="outlined"
            fullWidth
            href="/login"
            onClick={() => setMobileMenuOpen(false)}
            sx={{
              color: 'white',
              borderRadius: 20,
              backgroundColor: 'rgba(255, 255, 255, 0.1)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              backdropFilter: 'blur(12px)',
              '&:hover': {
                backgroundColor: 'rgba(255, 255, 255, 0.2)',
                borderColor: 'white',
              },
            }}
          >
            Login
          </Button>
        </Box>
      </Drawer>
    </>
  );
}
