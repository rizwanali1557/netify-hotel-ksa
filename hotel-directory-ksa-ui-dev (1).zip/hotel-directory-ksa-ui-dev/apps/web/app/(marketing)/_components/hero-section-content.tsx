'use client';
import { Box, Container, Stack, Typography } from '@mui/material';
import { AppLogo } from '~/components/app-logo';
import { HotelSearchForm } from '~/components/hotel-search';
import { fustat, radon } from '~/lib/fonts';
export default function HeroSectionContent_Client() {
  return (
    <Box
      sx={{
        position: 'relative',
        width: '100%',
        minHeight: '100vh',
        display: 'flex',
        pt: { xs: 16, md: 35 },
      }}
    >

      <Container maxWidth="xl" sx={{ px: { xs: 2, md: 4 }, position: 'relative', zIndex: 2 }}>
        <Stack
          direction="column"
          spacing={5}
          sx={{
            textAlign: 'left',
            maxWidth: { xs: '100%', md: '70%' },
          }}
        >
          <Box>
            <Typography
              variant="h1"
              sx={{ fontFamily: radon.style.fontFamily }}
            >
              Welcome
            </Typography>
            <Typography
              variant="h6"
              sx={{ fontFamily: fustat.style.fontFamily }}
              fontWeight={500}
            >
              Best Offers Of Hotels In Makkah and Madina
            </Typography>
          </Box>

          <HotelSearchForm glassyBackground />
        </Stack>
      </Container>

      {/* Decorative Logo background */}
      <Box
        sx={{
          position: 'absolute',
          right: 30,
          opacity: 0.08,
          zIndex: 1,
        }}
      >
        <AppLogo version="1" size={300} />
      </Box>
    </Box>
  );
}
