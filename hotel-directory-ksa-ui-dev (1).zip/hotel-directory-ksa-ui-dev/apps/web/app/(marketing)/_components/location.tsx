'use client';

import { Box, Container, Grid, Skeleton, Typography } from '@mui/material';
import { useTheme } from '@mui/material/styles';

import { useLocations } from '@kit/supabase/hooks/use-location';

import { radon,fustat } from '~/lib/fonts';
import { getFullSupabaseUrl } from '~/lib/utils/supabase-images';

const LocationSection = () => {
  const theme = useTheme();
  const { data: locations, error: locationsError, isLoading } = useLocations();

  if (locationsError)
    return <Typography color="error">Error loading locations</Typography>;

  const displayedLocations = locations?.slice(0, 4) || [];

  return (
    <Box sx={{ position: 'relative', maxWidth: '100dvw', overflow: 'hidden' }}>
      <Box
        component="img"
        src="/images/pattern-image.svg"
        alt="Pattern Decoration"
        sx={{
          position: 'absolute',
          top: '0',
          right: '0',
          width: '20%',
          height: '20%',
          objectFit: 'none',
          zIndex: 0,
        }}
      />
      <Container maxWidth="xl">
        <Box
          sx={{
            position: 'relative',
            width: '100%',
            padding: '70px 0',
            backgroundColor: theme.palette.background.default,
          }}
        >
          {/* Top Title */}
          <Typography
            variant="h2"
            sx={{
              fontWeight: 700,
              color: theme.palette.primary.main,
              mb: 4,
              fontFamily: radon.style.fontFamily,
            }}
          >
            The Best Hotels To Stay In
          </Typography>

          {/* 2x2 Grid */}
          <Grid container spacing={20} sx={{ position: 'relative' }}>
            {/* Centered Overlay Text */}
            <Box
              sx={{
                position: 'absolute',
                width: '100%',
                top: '49%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                pointerEvents: 'none',
              }}
            >
              <Typography
                variant="body1"
                sx={{
                  fontWeight: 700,
                  width: '45%',
                  fontSize: '4rem',
                  WebkitTextStroke: `1px ${theme.palette.primary.main}`,
                  color: 'white',
                  textAlign: 'right',
                  lineHeight: 1,
                }}
              >
                EXPLORE
              </Typography>
              <Typography
                variant="body1"
                sx={{
                  fontWeight: 700,
                  width: '65%',
                  fontSize: '4rem',
                  WebkitTextStroke: `1px ${theme.palette.primary.main}`,
                  color: 'white',
                  lineHeight: 1,
                  marginLeft: 'auto', 
                }}
              >
                BEST HOTELS
              </Typography>
            </Box>

            {isLoading
              ? // Show skeleton loaders while loading
                Array.from(new Array(4)).map((_, idx) => {
                  const scale = idx === 0 || idx === 2 ? 0.85 : 1;
                  return (
                    <Grid key={idx} size={{ xs: 12, md: 6 }}>
                      <Box
                        sx={{
                          position: 'relative',
                          width: '100%',
                          height: 300,
                          display: 'flex',
                          justifyContent: 'flex-start',
                          alignItems: 'flex-start',
                        }}
                      >
                        <Box
                          sx={{
                            width: `${scale * 100}%`,
                            height: `${scale * 100}%`,
                            display: 'flex',
                            flexDirection: 'column',
                          }}
                        >
                          <Skeleton
                            variant="rectangular"
                            width="100%"
                            height="100%"
                            sx={{ borderRadius: 1 }}
                          />
                          <Skeleton
                            width="60%"
                            height={40}
                            sx={{ mt: 1, mb: 3 }}
                          />
                        </Box>
                      </Box>
                    </Grid>
                  );
                })
              : // Show actual content when loaded
                displayedLocations.map((location, idx) => {
                  const scale = idx === 0 || idx === 2 ? 0.85 : 1;
                  return (
                    <Grid key={location.id} size={{ xs: 12, md: 6 }}>
                      <Box
                        sx={{
                          position: 'relative',
                          width: '100%',
                          height: 'auto',
                          display: 'flex',
                          justifyContent: 'flex-start',
                          alignItems: 'flex-start',
                          zIndex: 1000,
                        }}
                      >
                        <Box
                          sx={{
                            width: `${scale * 100}%`,
                            display: 'flex',
                            flexDirection: 'column',
                          }}
                        >
                          <Box
                            component="img"
                            src={getFullSupabaseUrl(location.thumbnail)}
                            alt={location.name}
                            sx={{
                              width: '100%',
                              height: idx % 2 === 0 ? 300 : 400,
                              objectFit: 'cover',
                              borderRadius: 2,
                              boxShadow: 3,
                              transition:
                                'transform 0.4s ease, box-shadow 0.4s ease',
                              cursor: 'pointer',
                              '&:hover': {
                                transform: 'translateY(-8px) scale(1.03)',
                                boxShadow: 6,
                              },
                            }}
                          />

                          <Typography
                            sx={{
                              textAlign: 'left',
                              fontWeight: 500,
                              fontSize: '2rem',
                              fontFamily: fustat.style.fontFamily,
                              mt: 1,
                              mb: 3,
                              color: theme.palette.primary.main,
                            }}
                          >
                            {location.name}
                          </Typography>
                        </Box>
                      </Box>
                    </Grid>
                  );
                })}
          </Grid>
        </Box>
      </Container>
      <Box
        component="img"
        src="/images/pattern-image.svg"
        alt="Pattern Decoration"
        sx={{
          position: 'absolute',
          bottom: '0',
          left: '0',
          width: '30%',
          height: '30%',
          objectFit: 'none',
          zIndex: 0, // Behind content
        }}
      />
    </Box>
  );
};

export default LocationSection;
