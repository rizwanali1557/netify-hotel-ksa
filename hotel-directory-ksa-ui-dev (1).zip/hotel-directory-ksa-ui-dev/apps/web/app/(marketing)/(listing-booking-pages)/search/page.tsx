"use client";

import { Box, Container, Grid } from "@mui/material";
import { useAvailableHotels } from "@kit/supabase/hooks/use-search-hotels";
import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { HotelFilters } from "~/components/hotel-filters";
import { HotelSearchResults } from "~/components/hotel-search-results";
import { Hotel } from "@kit/supabase/hooks/use-search-hotels";

export default function HotelsPage() {
  const { data: hotels, isLoading, error } = useAvailableHotels();
  const searchParams = useSearchParams();
  const cityName = searchParams?.get("city") || "Unknown City";

  const [filteredHotels, setFilteredHotels] = useState<Hotel[]>([]);

  useEffect(() => {
    if (hotels) setFilteredHotels(hotels);
  }, [hotels]);

  const handleFilterApply = (filtered: Hotel[]) => {
    setFilteredHotels(filtered);
  };

  if (isLoading) return <div>Loading hotels...</div>;
  if (error) return <div>{error.message}</div>;

  return (
    <Box
      sx={{
        backgroundColor: "#f5f5f5",
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Container maxWidth="xl" sx={{ flex: 1, py: 4 }}>
        <Grid container spacing={4} direction={{ xs: "column", lg: "row" }}>
          <Grid size={{ xs: 12, lg: 3 }}>
            <Box sx={{ backgroundColor: "transparent" }}>
              <HotelFilters
                hotels={hotels || []}
                cityName={cityName}
                onApply={handleFilterApply}
              />
            </Box>
          </Grid>

          <Grid size={{ xs: 12, lg: 9 }}>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                gap: 2,
                overflowX: { xs: "auto", lg: "visible" },
                "&::-webkit-scrollbar": { display: "none" },
                scrollbarWidth: "none",
                msOverflowStyle: "none",
              }}
            >
              <HotelSearchResults hotels={filteredHotels} />
            </Box>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
}
