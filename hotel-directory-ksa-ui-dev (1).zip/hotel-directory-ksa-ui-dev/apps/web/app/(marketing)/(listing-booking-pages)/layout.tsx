import { HotelSearchForm } from '~/components/hotel-search';

import { SiteHeader } from '../_components/site-header';

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div>
      <div className="bg-[#231F20] flex flex-col items-center space-y-8">
        <SiteHeader position="relative" />
        <div className="w-full md:w-4/5 py-4">
          <HotelSearchForm glassyBackground />
        </div>
      </div>
      {children}
    </div>
  );
}

export default Layout;
