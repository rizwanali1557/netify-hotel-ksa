
import { Hero } from '@kit/ui/marketing';
import BestHotelsSection from '~/(marketing)/_components/best-hotels';
import LocationSection from '~/(marketing)/_components/location';
import { withI18n } from '~/lib/i18n/with-i18n';
import HeroSectionContent_Client from './_components/hero-section-content';
import { SiteHeader } from './_components/site-header';
import Testimonial from './_components/testinomial';
function Home() {
  return (
    <div>
      <Hero>
        <SiteHeader />
        <HeroSectionContent_Client />
      </Hero>
      <div className={'flex flex-col'}>
        <div>
          <LocationSection />
          <BestHotelsSection />
        </div>
      </div>
      <Testimonial/>
    </div>
  );
}

export default withI18n(Home);
