import { getSupabaseServerClient } from '@kit/supabase/server-client';

import { withI18n } from '~/lib/i18n/with-i18n';
import { SiteFooter } from './_components/site-footer';

async function SiteLayout(props: React.PropsWithChildren) {
  const client = getSupabaseServerClient();

  const {
    data: { user },
  } = await client.auth.getUser();

  return (
    <div className="flex-col">
      <div>{props.children}</div>
      <SiteFooter/>
    </div>
  );
}

export default withI18n(SiteLayout);
