'use client';

import { Box, Typography, Rating, Chip, Stack } from '@mui/material';
import { LocationOn } from '@mui/icons-material';

export default function HotelOverview({ hotel }: { hotel: any }) {
  return (
    <Box>
      <Typography variant="h4" fontWeight={700}>
        {hotel.name}
      </Typography>
      <Stack direction="row" alignItems="center" spacing={1} mt={1}>
        <Rating value={hotel.class} readOnly size="small" />
        <Typography variant="body2" color="text.secondary">
          {hotel.class}-star hotel
        </Typography>
      </Stack>
      <Stack direction="row" alignItems="center" spacing={1} mt={1}>
        <LocationOn fontSize="small" color="action" />
        <Typography variant="body2">{hotel.address}</Typography>
      </Stack>
      <Typography variant="body2" mt={2} color="text.secondary">
        {hotel.description}
      </Typography>
      <Stack direction="row" spacing={1} mt={2} flexWrap="wrap">
        {hotel.hotel_facility?.map((hf: any) => (
          <Chip key={hf.facility.slug} label={hf.facility.name} size="small" />
        ))}
      </Stack>
    </Box>
  );
}
