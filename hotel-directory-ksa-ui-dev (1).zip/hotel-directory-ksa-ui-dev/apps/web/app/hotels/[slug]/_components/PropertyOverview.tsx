'use client';

import { Box, Typography, Grid, Stack } from '@mui/material';
import { FacilityIcon } from '~/components/icons';

export default function PropertyOverview({ facilities }: { facilities: any[] }) {
    const Icon = ({ icon_key }: { icon_key: string | null }) => <FacilityIcon icon_key={icon_key} />;
    
  return (
    <Box>
      <Typography variant="h5" fontWeight={700} gutterBottom>
        Property Overview
      </Typography>
      <Grid container spacing={2}>
        {facilities.map((f) => (
          <Grid size={{xs:6,md:4}} key={f.slug}>
            <Stack direction="row" spacing={1} alignItems="center">
              {f.icon && (
                <Icon icon_key={f.icon}/>
              )}
              <Typography variant="body2">{f.name}</Typography>
            </Stack>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
