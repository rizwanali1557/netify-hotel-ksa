'use client';

import { Box, Typography, Stack, Paper, Divider } from '@mui/material';

export default function Reviews({ reviews }: { reviews: any[] }) {
  if (!reviews.length) return null;

  const avg =
    reviews.reduce((acc, r) => acc + r.overall_rating, 0) / reviews.length;

  return (
    <Box>
      <Typography variant="h5" fontWeight={700} gutterBottom>
        Reviews
      </Typography>
      <Typography variant="h6" color="primary">
        {avg.toFixed(1)}/5
      </Typography>
      <Stack spacing={2} mt={2}>
        {reviews.map((r) => (
          <Paper key={r.id} sx={{ p: 2 }}>
            <Typography variant="subtitle2" fontWeight={600}>
              {r.reviewer_name}
            </Typography>
            <Typography variant="body2" color="text.secondary" mt={0.5}>
              {r.feedback}
            </Typography>
          </Paper>
        ))}
      </Stack>
    </Box>
  );
}
