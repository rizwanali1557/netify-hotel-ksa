'use client';

import { Box, IconButton } from '@mui/material';
import Image from 'next/image';
import { ChevronLeft, ChevronRight } from '@mui/icons-material';
import { useState } from 'react';

export default function HotelGallery({ images }: { images: any[] }) {
  const [idx, setIdx] = useState(0);
  const hasMultiple = images.length > 1;

  const go = (dir: number) => {
    setIdx((prev) => (prev + dir + images.length) % images.length);
  };

  return (
    <Box position="relative" height={{ xs: 220, md: 400 }} borderRadius={2} overflow="hidden">
      <Image
        src={images[idx]?.url || '/images/placeholder-hotel.png'}
        alt={images[idx]?.description || 'Hotel image'}
        fill
        style={{ objectFit: images.length > 0 ? 'cover' : 'contain' }}
        sizes="100vw"
        priority
      />

      {hasMultiple && (
        <>
          <IconButton
            onClick={() => go(-1)}
            sx={{ position: 'absolute', top: '50%', left: 8, bgcolor: 'white' }}
          >
            <ChevronLeft />
          </IconButton>
          <IconButton
            onClick={() => go(1)}
            sx={{ position: 'absolute', top: '50%', right: 8, bgcolor: 'white' }}
          >
            <ChevronRight />
          </IconButton>
        </>
      )}
    </Box>
  );
}
