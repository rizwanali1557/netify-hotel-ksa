'use client';

import { Card, CardContent, CardMedia, Typography, Box, Button, Stack } from '@mui/material';
import Image from 'next/image';

export default function RoomCard({ room }: { room: any }) {
  return (
    <Card sx={{ borderRadius: 3, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <Box position="relative" height={200}>
        <Image
          src={room.room_images?.[0]?.url || '/images/placeholder-room.jpg'}
          alt={room.name}
          fill
          style={{ objectFit: 'cover' }}
        />
      </Box>
      <CardContent>
        <Typography variant="h6" fontWeight={600}>{room.name}</Typography>
        <Typography variant="body2" color="text.secondary" mt={0.5}>
          {room.description}
        </Typography>
        <Stack direction="row" spacing={2} mt={2} alignItems="center">
          <Typography variant="h6" fontWeight={700}>
            SAR {room.price_per_night}
          </Typography>
          <Button variant="contained" color="primary" sx={{ borderRadius: 2, ml: 'auto' }}>
            Book Now
          </Button>
        </Stack>
      </CardContent>
    </Card>
  );
}
