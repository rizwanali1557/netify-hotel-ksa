'use client';

import { useParams } from 'next/navigation';

import { Box, CircularProgress, Container, Typography } from '@mui/material';

import { useHotelDetails } from '@kit/supabase/hooks/use-hotel-details';
import { useHotelReviews } from '@kit/supabase/hooks/use-hotel-reviews';
import { useHotelRooms } from '@kit/supabase/hooks/use-hotel-rooms';

import HotelGallery from './_components/HotelGallery';
import HotelOverview from './_components/HotelOverview';
import PropertyOverview from './_components/PropertyOverview';
import Reviews from './_components/Reviews';
import RoomCard from './_components/RoomCard';


export default function HotelPage() {
  const { slug } = useParams<{ slug: string }>();
  const { data: hotel, isLoading: hotelLoading } = useHotelDetails(slug);
  const { data: rooms, isLoading: roomsLoading } = useHotelRooms(slug);
  const { data: reviews, isLoading: reviewsLoading } = useHotelReviews(
    hotel?.id,
  );

  if (hotelLoading) {
    return (
      <Box display="flex" justifyContent="center" mt={8}>
        <CircularProgress />
      </Box>
    );
  }

  if (!hotel) {
    return (
      <Typography variant="h6" align="center">
        Hotel not found
      </Typography>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      {/* Gallery */}
      <HotelGallery images={hotel.hotel_images || []} />

      {/* Overview */}
      <Box mt={4}>
        <HotelOverview hotel={hotel} />
      </Box>

      {/* Rooms */}
      <Box mt={6}>
        <Typography variant="h5" fontWeight={700} gutterBottom>
          Rooms
        </Typography>
        <Box
          display="grid"
          gridTemplateColumns={{ xs: '1fr', md: '1fr 1fr' }}
          gap={3}
        >
          {rooms?.map((room: any) => <RoomCard key={room.id} room={room} />)}
        </Box>
      </Box>

      {/* Reviews */}
      <Box mt={6}>
        <Reviews reviews={reviews || []} />
      </Box>

      {/* Property Overview */}
      <Box mt={6}>
        <PropertyOverview
          facilities={hotel.hotel_facility?.map((hf: any) => hf.facility) || []}
        />
      </Box>
    </Container>
  );
}
