"use client";
import { useLocations } from '@kit/supabase/hooks/use-location';
import {useAllHotels} from '@kit/supabase/hooks/use-all-hotels';
import { CompactHotelCard } from '~/components/hotel-card';
import { useEffect, useState } from 'react';
import { useInView } from 'react-intersection-observer';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@kit/ui/select';
import { Skeleton } from '@kit/ui/skeleton';
import { radon } from '~/lib/fonts';
const HotelSkeleton = () => (
    <div className="mx-auto w-full max-w-[334px] overflow-hidden bg-secondary-tint shadow-center-sm">
    <Skeleton className="h-64 w-full" />
    <div className="flex w-full flex-col gap-4 p-4">
      <Skeleton className="h-6 w-3/4" />
      <Skeleton className="h-4 w-full" />
      <div className="flex justify-between">
        <Skeleton className="h-6 w-16" />
        <Skeleton className="h-6 w-20" />
      </div>
    </div>
  </div>
);

const PAGE_SIZE = 6;

export default function HotelsPage() {
  const [selectedLocation, setSelectedLocation] = useState('all');
  const [page, setPage] = useState(1);
  const [allHotels, setAllHotels] = useState<any[]>([]);
  const [hasMore, setHasMore] = useState(true); // Add this state
  const { ref, inView } = useInView();

  const { data: locations } = useLocations();
  const { data: hotels, isLoading } = useAllHotels(selectedLocation, page, PAGE_SIZE);

  useEffect(() => {
    if (hotels) {
      setAllHotels(prev => [...prev, ...hotels]);
      // Update hasMore based on whether we got a full page of results
      setHasMore(hotels.length === PAGE_SIZE);
    }
  }, [hotels]);

  useEffect(() => {
    if (inView && hasMore && !isLoading) {
      setPage(prev => prev + 1);
    }
  }, [inView, hasMore, isLoading]);

  useEffect(() => {
    // Reset when location changes
    setAllHotels([]);
    setPage(1);
    setHasMore(true); // Reset hasMore when location changes
  }, [selectedLocation]);

  return (
    <div className="container mx-auto px-6 pt-6 lg:px-10">
      <section className="sm:px-6 md:px-8 lg:px-8 xl:px-10">
        <div className="flex w-full flex-col items-center justify-between gap-4 pt-5 lg:flex-row">
          <h1 className={`text-3xl font-bold ${radon.className}`}>Discover our hotels</h1>
          <Select value={selectedLocation} onValueChange={setSelectedLocation}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select location" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Locations</SelectItem>
              {locations?.map(location => (
                <SelectItem key={location.id} value={location.slug || ''}>
                  {location.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </section>

      <div className="py-5 container mx-auto sm:px-6 md:px-8 lg:px-8 xl:px-10">
        <div className="mx-auto grid w-full grid-cols-1 gap-10 sm:grid-cols-1 lg:grid-cols-3 2xl:grid-cols-4">
          {allHotels.map(hotel => (
            <CompactHotelCard key={`${hotel.id}-${hotel.slug}`} hotel={hotel} />
          ))}
          {isLoading && Array.from({ length: 4 }).map((_, i) => (
            <HotelSkeleton key={`skeleton-${i}`} />
          ))}
        </div>
        <div ref={ref} className="h-10 w-full" />
      </div>
    </div>
  );
}