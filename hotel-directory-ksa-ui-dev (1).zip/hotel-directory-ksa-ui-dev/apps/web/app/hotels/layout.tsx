import { SiteFooter } from '~/(marketing)/_components/site-footer';
import { SiteHeader } from '~/(marketing)/_components/site-header';
import { HotelSearchForm } from '~/components/hotel-search';

export default function HotelsPageLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col">
      <div className="bg-[#231f20]">
        <SiteHeader />
      </div>
      <div className="bg-[#231f20] px-4 py-8 sm:px-6 md:px-8 lg:px-3 xl:px-12">
        <div className="mx-auto w-full md:max-w-5xl lg:max-w-7xl xl:max-w-[85rem]">
          <HotelSearchForm compactSearch />
        </div>
      </div>
      {children}
      <SiteFooter />
    </div>
  );
}
