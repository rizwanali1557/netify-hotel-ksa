export const dynamic = "force-dynamic";

import { BookingPageClient } from "./_components/BookingPageClient";

export default function BookingPage() {
  return <BookingPageClient />;
}