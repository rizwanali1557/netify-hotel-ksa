'use client';

import { useEffect, useState } from 'react';

import Image from 'next/image';
import { useRouter } from 'next/navigation';

import {
  Bed,
  Calendar,
  Clock,
  MapPin,
  Star,
  Users,
} from 'lucide-react';
import { ChevronsUpDown } from 'lucide-react';

import { useHotel } from '@kit/supabase/hooks/use-hotel';
import { Button } from '@kit/ui/button';
import { Card, CardContent } from '@kit/ui/card';
import {
  Command,
  CommandInput,
  CommandItem,
  CommandList,
} from '@kit/ui/command';
import { Input } from '@kit/ui/input';
import { Popover, PopoverContent, PopoverTrigger } from '@kit/ui/popover';
import { Separator } from '@kit/ui/separator';
import { Textarea } from '@kit/ui/textarea';

import { type Country, countries } from '~/lib/utils/dial-codes';

interface BookingData {
  hotelSlug: string;
  arrivalDate?: string;
  exitDate?: string;
  rooms: {
    id: string;
    name: string;
    price: number;
    quantity: number;
    beds: number;
  }[];
  totalPrice: number;
  totalNights: number;
}

export function BookingPageClient() {
  const router = useRouter();
  const [bookingData, setBookingData] = useState<BookingData | null>(null);
  const [selectedCountry, setSelectedCountry] = useState<Country>(
    countries[0]!,
  );
  const [openCountryDropdown, setOpenCountryDropdown] = useState(false);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    specialRequests: '',
  });
  // Get hotel data if slug is available
  const { data: hotel } = useHotel(bookingData?.hotelSlug || '');

  useEffect(() => {
    const data = sessionStorage.getItem('bookingData');
    if (data) {
      setBookingData(JSON.parse(data));
    } else {
      router.push('/hotels'); // Redirect if no booking data
    }
  }, [router]);

  if (!bookingData) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        Loading booking information...
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
  };

  const handleBack = () => {
    router.back();
  };

  return (
    <div className="bg-background min-h-screen pt-2">
      <section className="flex flex-col gap-4 py-10">
        <div className="container mx-auto grid w-full grid-cols-1 gap-6 px-4 lg:grid-cols-3 lg:px-6">
          {/* Left Column - Booking Info */}
          <div className="col-span-1 flex flex-col gap-6 lg:col-span-2">
            {/* Booking Information Card */}
            <Card className="shadow-sm">
              <CardContent className="p-6">
                <div className="mb-6">
                  <h1 className="text-3xl font-bold">Booking Information</h1>
                </div>

                <div className="flex flex-col gap-6 md:flex-row">
                  {/* Hotel Image */}
                  <div className="relative h-48 w-full overflow-hidden rounded-lg md:max-w-xs">
                    {hotel?.image_url && (
                      <Image
                        src={hotel?.image_url}
                        alt={hotel?.name}
                        fill
                        className="object-cover"
                        priority
                      />
                    )}
                  </div>

                  {/* Hotel Details */}
                  <div className="flex flex-1 flex-col gap-4">
                    <div className="flex flex-col gap-4 border-b pb-4">
                      <div className="flex flex-col gap-2">
                        <div className="flex items-center gap-1">
                          {[...Array(4)].map((_, i) => (
                            <Star
                              key={i}
                              className="fill-primary text-primary h-5 w-5"
                            />
                          ))}
                        </div>
                        <h2 className="truncate text-xl font-bold">
                          {hotel?.name || 'Loading hotel...'}
                        </h2>
                      </div>
                      <div className="text-muted-foreground flex items-start gap-2 text-sm">
                        <MapPin className="h-4 w-4" />
                        <span>{hotel?.address || 'Loading address...'}</span>
                      </div>
                    </div>

                    <div className="flex flex-col gap-2 border-b pb-4">
                      {bookingData.rooms.map((room) => (
                        <div key={room.id} className="flex items-center gap-2">
                          <Bed className="text-primary h-5 w-5" />
                          <span className="text-sm">
                            {room.quantity}x {room.name}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Guest Information Form */}
            <Card className="shadow-sm">
              <CardContent className="p-6">
                <h1 className="mb-6 text-3xl font-bold">
                  Enter your information
                </h1>
                <form
                  onSubmit={handleSubmit}
                  className="grid grid-cols-1 gap-4 md:grid-cols-2"
                >
                  <div className="space-y-2">
                    <label htmlFor="firstName" className="text-sm font-medium">
                      First name
                    </label>
                    <Input
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) =>
                        setFormData({ ...formData, firstName: e.target.value })
                      }
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="lastName" className="text-sm font-medium">
                      Last name
                    </label>
                    <Input
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) =>
                        setFormData({ ...formData, lastName: e.target.value })
                      }
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium">
                      Email
                    </label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="phone" className="text-sm font-medium">
                      Phone Number
                    </label>
                    <div className="flex rounded-md border">
                      <Popover
                        open={openCountryDropdown}
                        onOpenChange={setOpenCountryDropdown}
                      >
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            role="combobox"
                            aria-expanded={openCountryDropdown}
                            className="flex w-[150px] items-center justify-between gap-2 rounded-r-none border-0 border-r px-3 shadow-none"
                          >
                            <span className="truncate">
                              {selectedCountry.dialCode}
                            </span>
                            <ChevronsUpDown className="h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-[250px] p-0">
                          <Command>
                            <CommandInput placeholder="Search country..." />
                            <CommandList>
                              {countries.map((country) => (
                                <CommandItem
                                  key={country.code}
                                  value={`${country.name} ${country.dialCode}`}
                                  onSelect={() => {
                                    setSelectedCountry(country);
                                    setOpenCountryDropdown(false);
                                  }}
                                >
                                  <div className="flex w-full items-center justify-between">
                                    <span>{country.name}</span>
                                    <span className="text-muted-foreground">
                                      {country.dialCode}
                                    </span>
                                  </div>
                                </CommandItem>
                              ))}
                            </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>
                      <Input
                        id="phone"
                        type="tel"
                        className="border-0 focus-visible:ring-0"
                        value={formData.phone}
                        onChange={(e) =>
                          setFormData({ ...formData, phone: e.target.value })
                        }
                        required
                      />
                    </div>
                  </div>
                  <div className="md:col-span-2">
                    <h1 className="mb-4 text-3xl font-bold">
                      Special Requests
                    </h1>
                    <Textarea
                      id="specialRequests"
                      value={formData.specialRequests}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          specialRequests: e.target.value,
                        })
                      }
                      placeholder="Optional depending on the possibility and may be subject to additional fees"
                      className="h-36"
                    />
                  </div>

                  <div className="flex flex-col gap-2 md:col-span-2 md:flex-row md:justify-between">
                    <Button type="submit" className="w-full md:w-32">
                      Next
                    </Button>
                    <Button
                      variant="outline"
                      onClick={handleBack}
                      type="button"
                      className="w-full md:w-32"
                    >
                      Back to Home
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Summary */}
          <div className="col-span-1 flex flex-col gap-6">
            <Card className="shadow-sm">
              <CardContent className="p-6">
                <div className="space-y-7">
                  {/* Check-in/out times */}
                  <div className="space-y-4 border-b pb-4">
                    {[
                      { label: 'Check in', value: '16:00 - 20:00' },
                      { label: 'Check-out', value: '12:00 - 14:00' },
                    ].map(({ label, value }, i) => (
                      <div
                        key={label}
                        className="flex items-center justify-between"
                      >
                        <div className="flex items-center gap-2">
                          <Clock className="text-primary h-5 w-5" />
                          <span className="font-medium">{label}</span>
                        </div>
                        <span className="text-right font-bold">{value}</span>
                      </div>
                    ))}
                  </div>

                  {/* Dates & Guests */}
                  <div className="flex flex-col gap-6 border-b pb-4 md:flex-row md:items-center md:justify-between">
                    <div className="flex items-center gap-2">
                      <Calendar className="text-primary h-5 w-5" />
                      <span className="font-medium">
                        {bookingData.totalNights}{' '}
                        {bookingData.totalNights === 1 ? 'Night' : 'Nights'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="text-primary h-5 w-5" />
                      <span className="font-semibold">
                        {bookingData.rooms.reduce(
                          (sum, room) => sum + (room.beds * room.quantity),
                          0,
                        )}{' '}
                        Guests
                      </span>
                    </div>
                  </div>
                  <div className="mb-4 flex flex-col text-sm border-b md:flex-row md:justify-between">
                    <div>
                      <span className="block text-gray-500">From</span>
                      <span className="block font-medium">
                        {bookingData?.arrivalDate || '2025/08/01'}
                      </span>
                    </div>
                    <div>
                      <span className="block  text-gray-500">To</span>
                      <span className="block font-medium">
                        {bookingData?.exitDate || '2025/08/02'}
                      </span>
                    </div>
                  </div>

                  {/* Room Details */}
                  <div className="space-y-2 pb-4">
                    {bookingData.rooms.map((room) => (
                      <div
                        key={room.id}
                        className="flex items-center justify-between text-sm"
                      >
                        <div>
                          {room.quantity}x {room.name}
                        </div>
                        <div className="text-primary font-bold">
                          {room.price *
                            room.quantity}{' '}
                          <span className="font-normal text-black">SAR</span>
                        </div>
                      </div>
                    ))}
                    <div className="flex items-center justify-between text-sm text-gray-600">
                      <span>Including taxes and fees</span>
                      <span className="text-primary font-bold">0 SAR</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>Period</span>
                      <span className="font-bold">
                        {bookingData.totalNights}{' '}
                        {bookingData.totalNights === 1 ? 'Night' : 'Nights'}
                      </span>
                    </div>
                  </div>

                  {/* Total */}
                  <div className="mt-2 flex items-center justify-between border-t pt-5">
                    <span className="text-lg font-semibold">Total</span>
                    <span className="text-primary text-lg font-extrabold">
                      {bookingData.totalPrice.toFixed(2)} SAR
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Payment Policies Card */}
            <Card className="shadow-sm">
              <CardContent className="p-6">
                <h2 className="text-lg font-bold">Payment Policies</h2>
                <p className="text-destructive py-4 text-sm">
                  {hotel?.payment_policies}
                </p>
                <Separator className="my-4" />
                <p className="text-sm">
                  Please note that your reservation will be automatically
                  canceled if the due amounts are not paid before the specified
                  dates
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
