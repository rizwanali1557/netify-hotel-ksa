import { Loader2 } from "lucide-react";
import { type LucideProps } from "lucide-react";
import { cn } from "@kit/ui/utils";

export default function Loading() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-64px)] gap-4">
      <Spinner className="h-12 w-12" />
      <h2 className="text-xl font-semibold">Loading...</h2>
      <p className="text-muted-foreground">Please wait while we prepare your content</p>
    </div>
  );
}

function Spinner({ className, ...props }: LucideProps) {
  return (
    <Loader2
      className={cn("animate-spin text-primary", className)}
      {...props}
    />
  );
}