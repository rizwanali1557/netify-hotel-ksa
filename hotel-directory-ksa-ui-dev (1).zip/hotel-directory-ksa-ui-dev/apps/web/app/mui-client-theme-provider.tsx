'use client';

import { ReactNode } from 'react';

import CssBaseline from '@mui/material/CssBaseline';
import { ThemeProvider, createTheme } from '@mui/material/styles';

declare module '@mui/material/styles' {
  interface Palette {
    transparent: Palette['primary'];
  }
  interface PaletteOptions {
    transparent?: PaletteOptions['primary'];
  }
}

interface MuiThemeProviderProps {
  mode: 'light' | 'dark' | 'system';
  children: ReactNode;
}

export function MuiClientThemeProvider({
  children,
}: MuiThemeProviderProps) {
  const theme = createTheme({
    palette: {
      primary: {
        main: '#4d8a68', // New green theme color
        light: '#66BB6A',
        dark: '#1B5E20',
      },
      secondary: {
        main: '#C0CA33', // Complementary green shade
        light: '#E6EE9C',
        dark: '#9E9D24',
      },
      background: {
        default: '#ffffff',
      },
      transparent: {
        main: 'rgba(46, 125, 50, 0.1)',
        light: 'rgba(46, 125, 50, 0.05)',
        dark: 'rgba(46, 125, 50, 0.2)',
        contrastText: '#ffffff',
      },
    },
    typography: {
      fontFamily: [
        "'Inter'",
        'system-ui',
        '-apple-system',
        'BlinkMacSystemFont',
        '"Segoe UI"',
        'Roboto',
        '"Helvetica Neue"',
        'Arial',
        'sans-serif',
      ].join(','),
      h1: {
        fontFamily: "'Playfair Display', serif, Arial, sans-serif",
        fontWeight: 700,
      },
      h2: {
        fontFamily: "'Playfair Display', serif, Arial, sans-serif",
        fontWeight: 700,
      },
      h3: {
        fontFamily: "'Playfair Display', serif, Arial, sans-serif",
        fontWeight: 700,
      },
      h4: {
        fontFamily: "'Playfair Display', serif, Arial, sans-serif",
        fontWeight: 700,
      },
      h5: {
        fontFamily: "'Playfair Display', serif, Arial, sans-serif",
        fontWeight: 700,
      },
      h6: {
        fontFamily: "'Playfair Display', serif, Arial, sans-serif",
        fontWeight: 600,
      },
      body1: { fontFamily: "'Inter', system-ui, sans-serif" },
      body2: { fontFamily: "'Inter', system-ui, sans-serif" },
    },

    components: {
      MuiButton: {
        styleOverrides: {
          root: {
            textTransform: 'none',
            fontWeight: 500,
          },
          outlined: {
            borderWidth: 1.5,
            '&:hover': {
              borderWidth: 1.5,
            },
          },
        },
      },
      MuiTextField: {
        styleOverrides: {
          root: {
            color: 'white',
            padding: 2,
          },
        },
      },
      MuiContainer: {
        styleOverrides: {
          root: {
            '&.MuiContainer-maxWidthXl': {
              maxWidth: '1400px',
              paddingLeft: '24px',
              paddingRight: '24px',
            },
          },
        },
      },
      MuiLink: {
        styleOverrides: {
          root: {
            textDecoration: 'none',
            '&:hover': {
              textDecoration: 'none',
            },
          },
        },
      },
    },
  });

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      {children}
    </ThemeProvider>
  );
}
