import Link from "next/link";
import Image from "next/image";

type LogoVariant = "black" | "white";
type LogoVersion = "1" | "2" | "default";

interface LogoProps {
  href?: string | null;
  label?: string;
  variant?: LogoVariant; // black | white
  version?: LogoVersion; // 1 | 2 | default
  size?: number;
  className?: string;
}

export function AppLogo({
  href,
  label,
  variant = "white",
  version = "2",
  size = 50,
  className,
}: LogoProps) {
  // Construct image filename dynamically
  const baseName =
    version === "default"
      ? `${variant}_majestic rooms logo.png`
      : `${variant}_${version}_majestic rooms logo.png`;

  const image = (
    <Image
      className={className}
      width={size}
      height={size}
      src={`/images/logos/${baseName}`}
      alt={`${variant} logo`}
    />
  );

  // If no link needed, return just image
  if (href === null) return image;

  return (
    <Link aria-label={label ?? "Home Page"} href={href ?? "/"}>
      {image}
    </Link>
  );
}
