'use client';

import React from 'react';

import Image from 'next/image';
import Link from 'next/link';

import StarIcon from '@mui/icons-material/Star';
import {
  Badge,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  Divider,
  Grid,
  Stack,
  Typography,
  lighten,
  useTheme,
} from '@mui/material';
import { FaLocationDot } from 'react-icons/fa6';
import { FaKaaba } from 'react-icons/fa6';
import { HiLocationMarker } from 'react-icons/hi';

import type { HotelWithDetails } from '@kit/supabase/hooks/use-best-hotels';
import type { Hotel } from '@kit/supabase/hooks/use-search-hotels';

import { getFullSupabaseUrl } from '~/lib/utils/supabase-images';

import { FacilityIcon } from './icons';

export default function HotelCard({ hotel }: { hotel: Hotel }) {
  const mainImage =
    getFullSupabaseUrl(hotel.images[0]?.url) || '/images/placeholder-hotel.png';

  const hasPromotion =
    hotel.promotion?.is_active && hotel.promotion.discount_percent > 0;
  const discountedPrice = hasPromotion
    ? Math.round(
        hotel.min_price! * (1 - hotel.promotion!.discount_percent / 100),
      )
    : hotel.min_price;

  return (
    <Card
      sx={{
        display: 'flex',
        position: 'relative',
        width: '100%',
        maxWidth: 1100,
        mx: 'auto',
        overflow: 'hidden',
        borderRadius: 2,
        boxShadow: 3,
        p: 0.75,
      }}
    >
      {/* Left: Image */}
      <Box
        sx={{
          position: 'relative',
          width: '35%',
          minHeight: 300,
          borderRadius: 1.25,
          overflow: 'hidden',
          bgcolor: '#0001',
        }}
      >
        <Image
          src={mainImage}
          alt={hotel.name}
          fill
          style={{ objectFit: 'cover' }}
          sizes="(max-width: 1100px) 100vw, 35vw"
        />
      </Box>

      {/* Right: Content */}
      <CardContent
        sx={{
          display: 'flex',
          flexDirection: 'column',
          gap: 0.5,
          width: '65%',
          py: 1,
        }}
      >
        <Grid container>
          <Grid size={{ xs: 12, md: 9 }}>
            <Stack direction="column" gap={1}>
              {/* Top Section */}
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                {/* Rating + Name */}
                {hotel.class > 0 && (
                  <Box sx={{ display: 'flex', gap: 0.5 }}>
                    {Array.from({ length: hotel.class }).map((_, i) => (
                      <StarIcon
                        key={i}
                        sx={{ fontSize: 16, color: 'warning.main' }}
                      />
                    ))}
                  </Box>
                )}
                <Typography variant="h5" color="primary.main">
                  {hotel.name}
                </Typography>

                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <Box sx={{ color: 'primary.main' }}>
                    <HiLocationMarker />
                  </Box>
                  <Typography
                    variant="body2"
                    sx={{
                      display: '-webkit-box',
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: 'vertical',
                      overflow: 'hidden',
                    }}
                  >
                    {hotel.address}
                  </Typography>
                </Box>
              </Box>
              <Badge
                sx={{
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  gap: 1,
                  width: 'fit-content',
                  bgcolor: '#0001',
                  p: 1,
                  borderRadius: 1,
                }}
              >
                <Box sx={{ color: 'warning.main' }}>
                  <FaKaaba />
                </Box>
                <Typography variant="subtitle1" fontSize={14}>
                  {hotel.distance_from_haram}km from haram
                </Typography>
              </Badge>

              {/* Price */}
              {hotel.min_price !== null && (
                <Box
                  sx={{
                    mt: 1,
                    display: 'flex',
                    alignItems: 'baseline',
                    gap: 1,
                  }}
                >
                  {hasPromotion && (
                    <Typography
                      variant="body1"
                      color="#231F20"
                      sx={{
                        position: 'relative',
                        display: 'inline-block',
                        '&::after': {
                          content: '""',
                          position: 'absolute',
                          top: '50%',
                          left: 0,
                          width: '100%',
                          height: '2px',
                          backgroundColor: '#231F20',
                          transform: 'rotate(-15deg)', // adjust angle
                          transformOrigin: 'center',
                        },
                      }}
                    >
                      {hotel.min_price} <sup>SAR</sup>
                    </Typography>
                  )}

                  <Typography variant="h4" fontFamily="" color="warning.main">
                    {discountedPrice} <sup>SAR</sup>
                  </Typography>
                  <Typography variant="caption">
                    Inclusing taxes and fees* | For 1 night
                  </Typography>
                </Box>
              )}
            </Stack>
          </Grid>
          <Grid
            size={{ xs: 12, md: 3 }}
            sx={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            <Button
              sx={{
                bgcolor: 'primary.main',
                color: 'primary.contrastText',
                px: 3,
                py: 1.5,
                borderRadius: 10,
                transform: { md: 'translateY(100%)' },
              }}
            >
              Book Now
            </Button>
          </Grid>
        </Grid>
        <Divider sx={{ my: 2 }} />

        {/* Facilities */}
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
          {hotel.facilities.slice(0, 15).map((f) => (
            <Chip
              key={f.slug}
              label={f.name}
              size="small"
              sx={{
                backgroundColor: '#f5f5f5',
                fontSize: '0.75rem',
                px: 0.5,
              }}
              icon={f.icon ? <FacilityIcon icon_key={f.icon} /> : undefined}
            />
          ))}
        </Box>
      </CardContent>

      {/* Promotion Pill */}
      {hasPromotion && (
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            right: 0,
            bgcolor: (theme) => lighten(theme.palette.warning.main, 0.75),
            color: 'warning.main',
            fontSize: '0.75rem',
            px: 2,
            py: 1,
            display: 'flex',
            gap: 0.5,
          }}
        >
          <strong>
            {hotel.name
              .split(/[\s,-]+/)
              .slice(0, 2)
              .join(' ')}
          </strong>
          <span style={{ fontWeight: 400 }}>
            {hotel.promotion?.discount_percent}% OFF
          </span>
        </Box>
      )}
    </Card>
  );
}

const navBtnSx = (side: 'left' | 'right') => ({
  position: 'absolute',
  top: '50%',
  [side]: 10,
  transform: 'translateY(-50%)',
  bgcolor: 'rgba(0,0,0,.55)',
  color: '#fff',
  '&:hover': { bgcolor: 'rgba(0,0,0,.8)' },
  zIndex: 2,
});


export function CompactHotelCard({ hotel }: { hotel: HotelWithDetails }) {
  const theme = useTheme();
  const imageUrl = hotel.image_url
    ? getFullSupabaseUrl(hotel.image_url)
    : '/images/placeholder-hotel.png';
  const isPlaceholder = !hotel.image_url;

  return (
    <Link href={`/hotels/${hotel.slug}`} passHref>
      <Card
        sx={{
          width: 325,
          background: 'transparent',
          display: 'flex',
          p: 0.75,
          flexDirection: 'column',
          overflow: 'hidden',
          textDecoration: 'none',
          transition: 'all 0.3s ease',
          border: `1px solid black`,
          boxShadow: 'none',
          '&:hover': {
            borderColor: theme.palette.primary.main,
            boxShadow: `0 6px 14px ${theme.palette.grey[300]}`,
          },
        }}
      >
        <Box sx={{ position: 'relative', flex: '0 0 180px' }}>
          <Image
            src={imageUrl}
            alt={hotel.name}
            fill
            style={{
              objectFit: isPlaceholder ? 'contain' : 'cover',
              border: '0.1px solid black',
            }}
          />
        </Box>

        <CardContent
          sx={{ flexGrow: 1, px: 1, display: 'flex', flexDirection: 'column' }}
        >
          <Typography variant="subtitle1" fontWeight={600} noWrap>
            {hotel.name}
          </Typography>

          <Stack
            direction="row"
            alignItems="center"
            spacing={0.5}
            mt={0.5}
            mb={1}
          >
            <FaLocationDot size={12} color={theme.palette.primary.main} />
            <Typography variant="caption" color="text.secondary" noWrap>
              {hotel.address || 'Address not available'}
            </Typography>
          </Stack>

          <Divider sx={{ my: 1, backgroundColor: 'black' }} />

          <Box>
            <Button
              fullWidth
              sx={{
                position: 'relative',
                overflow: 'hidden',
                borderRadius: 1,
                color: theme.palette.primary.main,
                backgroundColor: 'transparent',
                textTransform: 'none',
                '&:before': {
                  content: '""',
                  position: 'absolute',
                  display: 'grid',
                  placeItems: 'center',
                  left: 0,
                  top: '50%',
                  transform: 'translateY(-50%)',
                  width: '100%',
                  height: 0,
                  bgcolor: theme.palette.primary.main,
                  zIndex: 0,
                  transition: 'height 0.3s ease',
                },
                '&:hover:before': {
                  height: '100%',
                  content: '"View Details"',
                },
                '&:hover': {
                  color: theme.palette.primary.contrastText,
                },
              }}
            >
              View Details
            </Button>
          </Box>
        </CardContent>
      </Card>
    </Link>
  );
}
