'use client';

import { useEffect, useMemo, useReducer } from 'react';

import { useRouter, useSearchParams } from 'next/navigation';

import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Button,
  Card,
  Checkbox,
  Divider,
  FormControlLabel,
  FormLabel,
  Radio,
  RadioGroup,
  TextField,
  Typography,
} from '@mui/material';

import { Hotel } from '@kit/supabase/hooks/use-search-hotels';

// -------------------- Filter Types & Reducer --------------------
export type FilterState = {
  name: string;
  stars: string[];
  maxDistance: string;
  meals: ('Room only' | 'Breakfast')[];
  views: ('No view' | 'City view')[];
  facilities: string[];
};

type FilterAction =
  | { type: 'SET_NAME'; value: string }
  | { type: 'SET_STARS'; value: string }
  | { type: 'SET_MAX_DISTANCE'; value: string }
  | { type: 'TOGGLE_MEAL'; value: 'Room only' | 'Breakfast' }
  | { type: 'TOGGLE_VIEW'; value: 'No view' | 'City view' }
  | { type: 'TOGGLE_FACILITY'; value: string }
  | { type: 'RESET' };

const initialState: FilterState = {
  name: '',
  stars: [],
  maxDistance: 'all',
  meals: [],
  views: [],
  facilities: [],
};

function filtersReducer(state: FilterState, action: FilterAction): FilterState {
  switch (action.type) {
    case 'SET_NAME':
      return { ...state, name: action.value };
    case 'SET_STARS':
      return {
        ...state,
        stars: state.stars.includes(action.value)
          ? state.stars.filter((s) => s !== action.value)
          : [...state.stars, action.value],
      };
    case 'SET_MAX_DISTANCE':
      return { ...state, maxDistance: action.value };
    case 'TOGGLE_MEAL':
      return {
        ...state,
        meals: state.meals.includes(action.value)
          ? state.meals.filter((v) => v !== action.value)
          : [...state.meals, action.value],
      };
    case 'TOGGLE_VIEW':
      return {
        ...state,
        views: state.views.includes(action.value)
          ? state.views.filter((v) => v !== action.value)
          : [...state.views, action.value],
      };
    case 'TOGGLE_FACILITY':
      return {
        ...state,
        facilities: state.facilities.includes(action.value)
          ? state.facilities.filter((v) => v !== action.value)
          : [...state.facilities, action.value],
      };
    case 'RESET':
      return initialState;
    default:
      return state;
  }
}

// -------------------- Component --------------------
interface HotelFiltersProps {
  hotels: Hotel[];
  cityName: string;
  onApply: (filteredHotels: Hotel[]) => void;
}

export function HotelFilters({ hotels, cityName, onApply }: HotelFiltersProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [state, dispatch] = useReducer(filtersReducer, initialState);

  // Compute counts
  const counts = useMemo(() => {
    const hotelsWithDerived = hotels.map((hotel) => ({
      ...hotel,
      serve_breakfast:
        !!hotel.promotion?.is_active && hotel.promotion.discount_percent > 0,
      has_city_view: hotel.facilities.some((f) =>
        f.name.toLowerCase().includes('view'),
      ),
    }));

    return {
      starCounts: [1, 2, 3, 4, 5].map((star) => ({
        star,
        count: hotelsWithDerived.filter((h) => h.class === star).length,
      })),
      distanceCounts: {
        all: hotelsWithDerived.length,
        '1': hotelsWithDerived.filter((h) => h.distance_from_haram < 1).length,
        '3': hotelsWithDerived.filter((h) => h.distance_from_haram < 3).length,
        '5': hotelsWithDerived.filter((h) => h.distance_from_haram < 5).length,
      },
      mealCounts: {
        'Room only': hotelsWithDerived.filter((h) => !h.serve_breakfast).length,
        Breakfast: hotelsWithDerived.filter((h) => h.serve_breakfast).length,
      },
      viewCounts: {
        'No view': hotelsWithDerived.filter((h) => !h.has_city_view).length,
        'City view': hotelsWithDerived.filter((h) => h.has_city_view).length,
      },
      facilityCounts: hotelsWithDerived
        .flatMap((h) => h.facilities.map((f) => f.slug))
        .reduce(
          (acc, slug) => {
            acc[slug] = (acc[slug] || 0) + 1;
            return acc;
          },
          {} as Record<string, number>,
        ),
    };
  }, [hotels]);

  // Filtered hotels
  const filteredHotels = useMemo(() => {
    return hotels.filter((h) => {
      if (
        state.name &&
        !h.name.toLowerCase().includes(state.name.toLowerCase())
      )
        return false;
      if (state.stars.length > 0 && !state.stars.includes(h.class.toString()))
        return false;
      if (
        state.maxDistance !== 'all' &&
        h.distance_from_haram >= parseInt(state.maxDistance)
      )
        return false;
      if (
        state.meals.length > 0 &&
        !state.meals.includes(
          h.promotion?.is_active && h.promotion.discount_percent > 0
            ? 'Breakfast'
            : 'Room only',
        )
      )
        return false;
      if (
        state.views.length > 0 &&
        !state.views.includes(
          h.facilities.some((f) => f.name.toLowerCase().includes('view'))
            ? 'City view'
            : 'No view',
        )
      )
        return false;
      if (
        state.facilities.length > 0 &&
        !state.facilities.every((slug) =>
          h.facilities.some((f) => f.slug === slug),
        )
      )
        return false;
      return true;
    });
  }, [hotels, state]);

  // URL Sync
  useEffect(() => {
    const params = new URLSearchParams(searchParams.toString());
    dispatch({ type: 'SET_NAME', value: params.get('name') || '' });
    params
      .getAll('stars')
      .forEach((s) => dispatch({ type: 'SET_STARS', value: s }));
    dispatch({
      type: 'SET_MAX_DISTANCE',
      value: params.get('maxDistance') || 'all',
    });
    params.getAll('meals').forEach((meal) => {
      if (meal === 'Room only' || meal === 'Breakfast')
        dispatch({ type: 'TOGGLE_MEAL', value: meal });
    });
    params.getAll('views').forEach((view) => {
      if (view === 'No view' || view === 'City view')
        dispatch({ type: 'TOGGLE_VIEW', value: view });
    });
    params
      .getAll('facilities')
      .forEach((slug) => dispatch({ type: 'TOGGLE_FACILITY', value: slug }));
  }, [searchParams]);

  const handleApply = () => {
    const params = new URLSearchParams();
    ['city', 'checkin', 'checkout'].forEach((k) => {
      if (searchParams.has(k)) params.set(k, searchParams.get(k) || '');
    });
    if (state.name) params.set('name', state.name);
    state.stars.forEach((s) => params.append('stars', s));
    if (state.maxDistance !== 'all')
      params.set('maxDistance', state.maxDistance);
    state.meals.forEach((m) => params.append('meals', m));
    state.views.forEach((v) => params.append('views', v));
    state.facilities.forEach((f) => params.append('facilities', f));
    router.push(`?${params.toString()}`);
    onApply(filteredHotels);
  };

  const handleClear = () => {
    dispatch({ type: 'RESET' });
    const params = new URLSearchParams();
    ['city', 'checkin', 'checkout'].forEach((k) => {
      if (searchParams.has(k)) params.set(k, searchParams.get(k) || '');
    });
    router.push(`?${params.toString()}`);
    onApply(hotels);
  };

  const mapUrl = `https://maps.google.com/maps?q=${encodeURIComponent(
    cityName,
  )}&z=12&output=embed`;

  // Helper for spaced labels
  const renderLabel = (text: string, count: number) => (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'space-between',
        flexGrow: 1,
      }}
    >
      <span>{text}</span>
      <Typography variant="body1" color="text.secondary">
        {count}
      </Typography>
    </Box>
  );

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      {/* Map Card */}
      <Card sx={{ borderRadius: 2, border: '1px solid lightgray' }}>
        <Box sx={{ position: 'relative', height: 150, overflow: 'hidden' }}>
          <iframe
            src={mapUrl}
            width="100%"
            height="100%"
            loading="lazy"
            style={{ border: 0 }}
          />
        </Box>
        <Box sx={{ p: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
          <LocationOnIcon sx={{ color: 'primary.main' }} />
          <Typography variant="h6" sx={{ textTransform: 'capitalize' }}>
            {cityName}
          </Typography>
        </Box>
      </Card>

      {/* Filters Card */}
      <Card
        sx={{
          borderRadius: 2,
          border: '1px solid lightgray',
          boxShadow: 'none',
        }}
      >
        <Box sx={{ p: 2, color: 'primary.main', bgcolor: '#4D8A6820' }}>
          <Typography
            variant="h2"
            sx={{ fontSize: '1.25rem', fontWeight: 'bold' }}
          >
            Filters
          </Typography>
        </Box>

        <Box sx={{ p: 2 }}>
          {/* Hotel Name */}
          <FormLabel sx={{ fontWeight: 'bold', mb: 1, display: 'block' }}>
            Hotel Name
          </FormLabel>
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Hotel name"
            value={state.name}
            onChange={(e) =>
              dispatch({ type: 'SET_NAME', value: e.target.value })
            }
            sx={{ mb: 2, '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
          />

          <Divider sx={{ my: 2 }} />


           {/* Distance */}
          <Accordion
            sx={{
              boxShadow: 'none',
              '&::before': { display: 'none' }, // <- removes the thin border line before AccordionSummary
            }}
            disableGutters
            elevation={0}
            square
            defaultExpanded
          >
            <AccordionSummary sx={{padding:0}} expandIcon={<ExpandMoreIcon />}>
              <Typography sx={{ fontWeight: 'bold' }}>
                Distance from Haram
              </Typography>
            </AccordionSummary>
            <AccordionDetails sx={{ p: 0 }}>
              <RadioGroup
                value={state.maxDistance}
                onChange={(e) =>
                  dispatch({ type: 'SET_MAX_DISTANCE', value: e.target.value })
                }
              >
                {['all', '1', '3', '5'].map((range) => (
                  <FormControlLabel
                    key={range}
                    value={range}
                    control={<Radio color="primary" />}
                    label={renderLabel(
                      range === 'all' ? 'All' : `Less than ${range} km`,
                      counts.distanceCounts[range as 'all'],
                    )}
                    sx={{
                      width: '100%',
                      '& .MuiFormControlLabel-label': {
                        display: 'flex',
                        flex: 1,
                      },
                    }}
                  />
                ))}
              </RadioGroup>
            </AccordionDetails>
          </Accordion>

          <Divider sx={{ my: 2 }} />

          {/* Hotel Class */}
          <Accordion
            sx={{
              boxShadow: 'none',
              '&::before': { display: 'none' }, // <- removes the thin border line before AccordionSummary
            }}
            disableGutters
            elevation={0}
            square
            defaultExpanded
          >
            <AccordionSummary sx={{padding:0}} expandIcon={<ExpandMoreIcon />}>
              <Typography sx={{ fontWeight: 'bold' }}>Hotel Class</Typography>
            </AccordionSummary>
            <AccordionDetails sx={{ p: 0, flexDirection: 'column' }}>
              {counts.starCounts.map(({ star, count }) => (
                <FormControlLabel
                  key={star}
                  control={
                    <Checkbox
                      color="primary"
                      checked={state.stars.includes(star.toString())}
                      onChange={() =>
                        dispatch({ type: 'SET_STARS', value: star.toString() })
                      }
                    />
                  }
                  label={renderLabel(`${star} Star`, count)}
                  sx={{
                    width: '100%',
                    '& .MuiFormControlLabel-label': {
                      display: 'flex',
                      flex: 1,
                    },
                  }}
                />
              ))}
            </AccordionDetails>
          </Accordion>

          <Divider sx={{ my: 2 }} />

         

          {/* Meals */}
          <Accordion
            sx={{
              boxShadow: 'none',
              '&::before': { display: 'none' }, // <- removes the thin border line before AccordionSummary
            }}
            disableGutters
            elevation={0}
            square
            defaultExpanded
          >
            <AccordionSummary sx={{padding:0}} expandIcon={<ExpandMoreIcon />}>
              <Typography sx={{ fontWeight: 'bold' }}>Meals</Typography>
            </AccordionSummary>
            <AccordionDetails sx={{ p: 0 }}>
              {(['Room only', 'Breakfast'] as const).map((meal) => (
                <FormControlLabel
                  key={meal}
                  control={
                    <Checkbox
                      color="primary"
                      checked={state.meals.includes(meal)}
                      onChange={() =>
                        dispatch({ type: 'TOGGLE_MEAL', value: meal })
                      }
                    />
                  }
                  label={renderLabel(meal, counts.mealCounts[meal])}
                  sx={{
                    width: '100%',
                    '& .MuiFormControlLabel-label': {
                      display: 'flex',
                      flex: 1,
                    },
                  }}
                />
              ))}
            </AccordionDetails>
          </Accordion>

          <Divider sx={{ my: 2 }} />

          {/* Views */}
          <Accordion
            sx={{
              boxShadow: 'none',
              '&::before': { display: 'none' }, // <- removes the thin border line before AccordionSummary
            }}
            disableGutters
            elevation={0}
            square
            defaultExpanded
          >
            <AccordionSummary sx={{padding:0}} expandIcon={<ExpandMoreIcon />}>
              <Typography sx={{ fontWeight: 'bold' }}>Views</Typography>
            </AccordionSummary>
            <AccordionDetails sx={{ p: 0 }}>
              {(['No view', 'City view'] as const).map((view) => (
                <FormControlLabel
                  key={view}
                  control={
                    <Checkbox
                      color="primary"
                      checked={state.views.includes(view)}
                      onChange={() =>
                        dispatch({ type: 'TOGGLE_VIEW', value: view })
                      }
                    />
                  }
                  label={renderLabel(view, counts.viewCounts[view])}
                  sx={{
                    width: '100%',
                    '& .MuiFormControlLabel-label': {
                      display: 'flex',
                      flex: 1,
                    },
                  }}
                />
              ))}
            </AccordionDetails>
          </Accordion>

          <Divider sx={{ my: 2 }} />

          {/* Facilities */}
          <Accordion
            sx={{
              boxShadow: 'none',
              '&::before': { display: 'none' }, // <- removes the thin border line before AccordionSummary
            }}
            disableGutters
            elevation={0}
            square
            defaultExpanded
          >
            <AccordionSummary sx={{padding:0}} expandIcon={<ExpandMoreIcon />}>
              <Typography sx={{ fontWeight: 'bold' }}>Facilities</Typography>
            </AccordionSummary>
            <AccordionDetails sx={{ p: 0 }}>
              {Object.entries(counts.facilityCounts).map(([slug, count]) => (
                <FormControlLabel
                  key={slug}
                  control={
                    <Checkbox
                      color="primary"
                      checked={state.facilities.includes(slug)}
                      onChange={() =>
                        dispatch({ type: 'TOGGLE_FACILITY', value: slug })
                      }
                    />
                  }
                  label={renderLabel(
                    slug.replace('-', ' ').toUpperCase(),
                    count,
                  )}
                  sx={{
                    width: '100%',
                    '& .MuiFormControlLabel-label': {
                      display: 'flex',
                      flex: 1,
                    },
                  }}
                />
              ))}
            </AccordionDetails>
          </Accordion>

          {/* Buttons */}
          <Box sx={{ mt: 3, display: 'flex', gap: 2 }}>
            <Button
              onClick={handleClear}
              sx={{
                color: 'primary.main',
                minHeight: 44,
                px: 2,
                whiteSpace: 'nowrap',
              }}
            >
              Clear
            </Button>
            <Button
              variant="contained"
              color="primary"
              onClick={handleApply}
              sx={{ flex: 1, minHeight: 44, px: 2, whiteSpace: 'nowrap' }}
            >
              Show {filteredHotels.length}/{hotels.length} hotels
            </Button>
          </Box>
        </Box>
      </Card>
    </Box>
  );
}
