'use client';

import { useEffect, useState } from 'react';
import HotelCard from './hotel-card';
import { Hotel } from '@kit/supabase/hooks/use-search-hotels';
import { Stack } from '@mui/material';

interface DateInfo {
  checkin: string | null;
  checkout: string | null;
  city: string | null;
  totalNights: number;
}

interface HotelSearchResultsProps {
  hotels: Hotel[];
}

export function HotelSearchResults({ hotels }: HotelSearchResultsProps) {
  const [dateInfo, setDateInfo] = useState<DateInfo>({
    checkin: null,
    checkout: null,
    city: null,
    totalNights: 0,
  });

  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const checkinParam = searchParams.get('checkin');
    const checkoutParam = searchParams.get('checkout');
    const city = searchParams.get('city');

    if (checkinParam && checkoutParam) {
      try {
        const checkinDate = new Date(checkinParam);
        const checkoutDate = new Date(checkoutParam);

        if (isNaN(checkinDate.getTime())) throw new Error('Invalid checkin date');
        if (isNaN(checkoutDate.getTime())) throw new Error('Invalid checkout date');
        if (checkoutDate <= checkinDate) throw new Error('Checkout must be after checkin');

        const timeDiff = checkoutDate.getTime() - checkinDate.getTime();
        const nights = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));

        setDateInfo({
          checkin: checkinParam,
          checkout: checkoutParam,
          city,
          totalNights: nights,
        });
      } catch (error) {
        console.error('Error processing dates:', error);
        setDateInfo({
          checkin: checkinParam,
          checkout: checkoutParam,
          city,
          totalNights: 0,
        });
      }
    } else {
      setDateInfo({
        checkin: null,
        checkout: null,
        city: null,
        totalNights: 0,
      });
    }
  }, []);

  return (
    <Stack direction="column" flex={1} gap={5}>
        {hotels.map((hotel) => (
          <HotelCard key={hotel.name} hotel={hotel} />
        ))}
    </Stack>
  );
}