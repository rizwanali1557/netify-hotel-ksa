'use client';

import React, { useEffect, useReducer, useState } from 'react';

import { useSearchParams } from 'next/navigation';

import {
  ArrowDropDown,
  EventAvailable,
  EventBusy,
  LocationOn,
} from '@mui/icons-material';
import {
  Box,
  Button,
  Grid,
  InputAdornment,
  MenuItem,
  Paper,
  Popover,
  TextField,
  Tooltip,
  Typography,
  useTheme,
} from '@mui/material';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { DateCalendar } from '@mui/x-date-pickers/DateCalendar';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { PickersDay, PickersDayProps } from '@mui/x-date-pickers/PickersDay';
import { parse } from 'date-fns';
import {
  addDays,
  addMonths,
  differenceInDays,
  format,
  isAfter,
  isBefore,
  isSameDay,
  startOfDay,
  startOfMonth,
} from 'date-fns';

import { useLocations } from '@kit/supabase/hooks/use-location';

// -------------------- Types --------------------
interface Location {
  id: string;
  name: string;
  slug?: string;
  thumbnail?: string;
}
interface SearchState {
  startDate: Date | null;
  endDate: Date | null;
  promoCode: string;
  selectedLocation: Location;
  calendarAnchorEl: HTMLElement | null;
}
type SearchAction =
  | { type: 'SET_START_DATE'; payload: Date | null }
  | { type: 'SET_END_DATE'; payload: Date | null }
  | { type: 'SET_PROMO_CODE'; payload: string }
  | { type: 'SET_LOCATION'; payload: Location }
  | { type: 'OPEN_CALENDAR'; payload: HTMLElement }
  | { type: 'CLOSE_CALENDAR' };

const searchReducer = (
  state: SearchState,
  action: SearchAction,
): SearchState => {
  switch (action.type) {
    case 'SET_START_DATE':
      return { ...state, startDate: action.payload };
    case 'SET_END_DATE':
      return { ...state, endDate: action.payload };
    case 'SET_PROMO_CODE':
      return { ...state, promoCode: action.payload };
    case 'SET_LOCATION':
      return { ...state, selectedLocation: action.payload };
    case 'OPEN_CALENDAR':
      return { ...state, calendarAnchorEl: action.payload };
    case 'CLOSE_CALENDAR':
      return { ...state, calendarAnchorEl: null };
    default:
      return state;
  }
};

// -------------------- Styles --------------------
const inputStyles = {
  '& .MuiInputBase-root': {
    color: 'rgba(255,255,255,0.9)', // WCAG 4.5:1 contrast
    padding: '0 8px', // Reduced internal padding
    height: '48px', // Compact height
    backgroundColor: 'rgba(255,255,255,0.08)',
    transition: 'background-color 0.2s',
    borderRadius: '30px',
    '&:hover': {
      backgroundColor: 'rgba(255,255,255,0.15)', // Lighter background on hover
    },
  },
  '& .MuiInputLabel-root': {
    display: 'none', // Remove floating labels
  },
  '& .MuiOutlinedInput-notchedOutline': {
    border: 'none', // No borders
  },
};

// -------------------- Small components --------------------
const LocationSelector: React.FC<{
  locations: Location[];
  selectedLocation: Location;
  onLocationChange: (loc: Location) => void;
  isLoading: boolean;
  error: any;
}> = ({ locations, selectedLocation, onLocationChange, isLoading, error }) => {
  return (
    <TextField
      select
      placeholder="Select destination"
      value={
        isLoading ? 'loading' : error ? 'error' : selectedLocation.id || ''
      }
      onChange={(e) => {
        const id = e.target.value as string;
        const found = locations.find((l) => l.id === id);
        if (found) onLocationChange(found);
      }}
      SelectProps={{
        IconComponent: () => null,
      }}
      InputProps={{
        startAdornment: (
          <InputAdornment position="start">
            <LocationOn
              sx={{
                fontSize: 24,
                transition: 'color 0.2s',
                color: 'primary.main',
                '&:hover': { color: 'primary.dark' },
              }}
            />
          </InputAdornment>
        ),
        endAdornment: (
          <InputAdornment position="end">
            <ArrowDropDown
              sx={{ fontSize: 24, color: 'rgba(255,255,255,0.8)' }}
            />
          </InputAdornment>
        ),
      }}
      fullWidth
      disabled={isLoading || !!error}
      sx={{
        ...inputStyles,
        '& .MuiSelect-select': { textOverflow: 'ellipsis' },
      }}
    >
      {isLoading ? (
        <MenuItem value="loading" disabled>
          Loading locations...
        </MenuItem>
      ) : error ? (
        <MenuItem value="error" disabled>
          Error loading
        </MenuItem>
      ) : locations.length === 0 ? (
        <MenuItem value="" disabled>
          No locations available
        </MenuItem>
      ) : (
        locations.map((loc) => (
          <MenuItem key={loc.id} value={loc.id}>
            {loc.name}
          </MenuItem>
        ))
      )}
    </TextField>
  );
};

const DateInput: React.FC<{
  label: string;
  value: string;
  onClick: (e: React.MouseEvent<HTMLElement>) => void;
  icon: React.ReactNode;
  disabled?: boolean;
}> = ({ label, value, onClick, icon, disabled = false }) => (
  <TextField
    placeholder={label}
    value={value || 'Select date'}
    onClick={onClick}
    disabled={disabled}
    fullWidth
    sx={inputStyles}
    InputProps={{
      readOnly: true,
      startAdornment: (
        <InputAdornment position="start">
          <Box
            sx={{
              fontSize: 24,
              transition: 'color 0.2s',
              color: 'primary.main',
              '&:hover': { color: 'primary.dark' },
            }}
          >
            {icon}
          </Box>
        </InputAdornment>
      ),
      endAdornment: (
        <InputAdornment position="end">
          <ArrowDropDown
            sx={{ fontSize: 24, color: 'rgba(255,255,255,0.8)' }}
          />
        </InputAdornment>
      ),
    }}
  />
);

interface CustomPickersDayProps extends PickersDayProps {
  startDate: Date | null;
  endDate: Date | null;
  hoverDate: Date | null;
  isSelectingStart: boolean;
}
const CustomPickersDay: React.FC<CustomPickersDayProps> = ({
  day,
  startDate,
  endDate,
  hoverDate,
  isSelectingStart,
  ...other
}) => {
  const isStart = !!startDate && isSameDay(day, startDate);
  const isEnd = !!endDate && isSameDay(day, endDate);
  const isInRange =
    startDate && endDate && isAfter(day, startDate) && isBefore(day, endDate);
  const isInHoverRange =
    startDate &&
    hoverDate &&
    !endDate &&
    isAfter(hoverDate, startDate) &&
    isAfter(day, startDate) &&
    isBefore(day, hoverDate);
  const tooltipTitle = isSelectingStart
    ? 'Check-in Date'
    : startDate && isAfter(day, startDate)
      ? 'Check-out Date'
      : 'Check-in Date';
  return (
    <Tooltip title={tooltipTitle} arrow>
      <PickersDay
        {...other}
        day={day}
        sx={(theme) => {
          let styles: any = {
            transition: 'background-color 0.15s ease, color 0.15s ease',
          };
          if (isStart || isEnd) {
            styles = {
              ...styles,
              bgcolor: theme.palette.primary.main,
              color: theme.palette.primary.contrastText,
              borderRadius: '6px',
              '&:hover': {
                bgcolor: theme.palette.primary.main,
                color: theme.palette.primary.contrastText,
              },
            };
          } else if (isInRange) {
            styles = {
              ...styles,
              bgcolor: theme.palette.primary.main + '20',
              color: theme.palette.text.primary,
              borderRadius: 0,
            };
          } else if (isInHoverRange) {
            styles = {
              ...styles,
              bgcolor: theme.palette.primary.main + '10',
              color: theme.palette.text.primary,
              borderRadius: 0,
            };
          } else {
            styles = {
              ...styles,
              '&:hover': {
                bgcolor: theme.palette.action.hover,
                color: theme.palette.text.primary,
              },
            };
          }
          return styles;
        }}
      />
    </Tooltip>
  );
};

interface CalendarComponentProps {
  open: boolean;
  anchorEl: HTMLElement | null;
  onClose: () => void;
  startDate: Date | null;
  endDate: Date | null;
  onDatesChange: (start: Date | null, end: Date | null) => void;
}

const CalendarComponent: React.FC<CalendarComponentProps> = ({
  open,
  anchorEl,
  onClose,
  startDate,
  endDate,
  onDatesChange,
}) => {
  const today = startOfDay(new Date());
  const [selectedStart, setSelectedStart] = useState<Date | null>(startDate);
  const [selectedEnd, setSelectedEnd] = useState<Date | null>(endDate);
  const [hoverDate, setHoverDate] = useState<Date | null>(null);
  const [leftMonth, setLeftMonth] = useState<Date>(
    startOfMonth(selectedStart ?? today),
  );
  const [isSelectingStart, setIsSelectingStart] = useState<boolean>(!startDate);

  useEffect(() => {
    setSelectedStart(startDate);
    setSelectedEnd(endDate);
  }, [startDate, endDate]);

  const nights =
    selectedStart && selectedEnd
      ? differenceInDays(selectedEnd, selectedStart)
      : 0;

  const handleDaySelect = (value: Date | null) => {
    if (!value || isBefore(value, today)) return;
    if (isSelectingStart || !selectedStart || isBefore(value, selectedStart)) {
      setSelectedStart(value);
      setSelectedEnd(null);
      setIsSelectingStart(false);
      setLeftMonth(startOfMonth(value));
    } else if (isAfter(value, selectedStart)) {
      setSelectedEnd(value);
      setIsSelectingStart(true);
    }
  };

  const handleApply = () => {
    if (selectedStart && selectedEnd) {
      onDatesChange(selectedStart, selectedEnd);
      onClose();
    }
  };

  const handleClear = () => {
    setSelectedStart(null);
    setSelectedEnd(null);
    setIsSelectingStart(true);
  };

  const canPrev =
    !!selectedStart && !isBefore(addDays(selectedStart, -1), today);
  const canNext = !!selectedStart && !!selectedEnd;
  const handleArrow = (dir: 'prev' | 'next') => {
    if (!selectedStart || !selectedEnd) return;
    const delta = dir === 'next' ? 1 : -1;
    const newStart = addDays(selectedStart, delta);
    const newEnd = addDays(selectedEnd, delta);
    if (isBefore(newStart, today)) return;
    setSelectedStart(newStart);
    setSelectedEnd(newEnd);
  };

  return (
    <Popover
      disableScrollLock
      open={open}
      anchorEl={anchorEl}
      onClose={onClose}
      anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      transformOrigin={{ vertical: 'top', horizontal: 'left' }}
      sx={{
        '& .MuiPaper-root': {
          p: 2,
          borderRadius: '16px',
          boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
          background: 'rgba(255,255,255)',
          maxWidth: { xs: '90vw', md: 'auto' },
        },
      }}
    >
      <Typography
        variant="h5"
        sx={{
          mb: 1,
          textAlign: 'center',
          fontFamily: 'Inter, sans-serif',
          letterSpacing: '0.5px',
        }}
      >
        Select Your Dates
      </Typography>

      {nights > 0 && (
        <Typography
          variant="body2"
          color="text.secondary"
          sx={{
            textAlign: 'center',
            mb: 1,
            fontFamily: 'Inter, sans-serif',
            letterSpacing: '0.5px',
          }}
        >
          {nights} Night{nights > 1 ? 's' : ''} Selected
        </Typography>
      )}

      <Box
        sx={{
          display: 'flex',
          flexDirection: { xs: 'column', md: 'row' },
          gap: 2,
          alignItems: 'flex-start',
        }}
      >
        <DateCalendar
          referenceDate={leftMonth}
          onMonthChange={setLeftMonth}
          minDate={today}
          onChange={handleDaySelect}
          value={null}
          slots={{
            day: (props) => (
              <CustomPickersDay
                {...props}
                startDate={selectedStart}
                endDate={selectedEnd}
                hoverDate={hoverDate}
                isSelectingStart={isSelectingStart}
                onMouseEnter={() => setHoverDate(props.day)}
                onMouseLeave={() => setHoverDate(null)}
              />
            ),
          }}
          sx={{ minWidth: 280 }}
        />

        <DateCalendar
          referenceDate={addMonths(leftMonth, 1)}
          minDate={today}
          onChange={handleDaySelect}
          value={null}
          slots={{
            day: (props) => (
              <CustomPickersDay
                {...props}
                startDate={selectedStart}
                endDate={selectedEnd}
                hoverDate={hoverDate}
                isSelectingStart={isSelectingStart}
                onMouseEnter={() => setHoverDate(props.day)}
                onMouseLeave={() => setHoverDate(null)}
              />
            ),
          }}
          sx={{ minWidth: 280 }}
        />
      </Box>

      <Box
        sx={{
          display: 'flex',
          flexDirection: 'row',
          gap: 2,
          justifyContent: 'flex-end',
          mt: 2,
        }}
      >
        <Button onClick={handleClear} color="secondary">
          Clear
        </Button>
        <Button
          onClick={handleApply}
          variant="contained"
          sx={{ borderRadius: '20px' }}
          disabled={!selectedStart || !selectedEnd}
        >
          Apply
        </Button>
      </Box>
    </Popover>
  );
};

// -------------------- Main form --------------------
export const HotelSearchForm: React.FC<{
  compactSearch?: boolean;
  glassyBackground?: boolean;
}> = ({ compactSearch = false, glassyBackground = false }) => {
  const theme = useTheme();
  const searchParams = useSearchParams();

  // Parse query parameters
  const citySlug = searchParams.get('city') ?? '';
  const checkin = searchParams.get('checkin');
  const checkout = searchParams.get('checkout');
  const rooms = searchParams.getAll('rooms');
  const promoCode = searchParams.get('promoCode') ?? '';

  // Initialize dates from query params or fallback to today/tomorrow
  const today = startOfDay(new Date());
  const tomorrow = addDays(today, 1);
  const parsedStartDate = checkin
    ? parse(checkin, 'yyyy-MM-dd', new Date())
    : today;
  const parsedEndDate = checkout
    ? parse(checkout, 'yyyy-MM-dd', new Date())
    : tomorrow;

  // Initialize rooms from query params or fallback to default
  const parsedRooms =
    rooms.length > 0
      ? rooms.map((r) => ({ adults: parseInt(r, 10) || 2 }))
      : [{ adults: 2 }];

  const initialState: SearchState = {
    startDate: parsedStartDate,
    endDate: parsedEndDate,
    promoCode,
    selectedLocation: { id: '', name: 'Select destination', slug: citySlug },
    calendarAnchorEl: null,
  };

  const [state, dispatch] = useReducer(searchReducer, initialState);
  const locRes: any = useLocations();
  const locations = (locRes.data ?? []) as Location[];
  const isLoading = !!locRes.isLoading;
  const error = locRes.error ?? null;

  // Update selectedLocation to first available location
  useEffect(() => {
    if (locations.length > 0 && !state.selectedLocation.id) {
      const matchingLocation =
        locations.find((loc) => loc.slug === citySlug) || locations[0];
      if (matchingLocation) {
        dispatch({ type: 'SET_LOCATION', payload: matchingLocation });
      }
    }
  }, [locations, state.selectedLocation.id, citySlug]);

  const nights =
    state.startDate && state.endDate
      ? differenceInDays(state.endDate, state.startDate)
      : 0;

  const isSearchDisabled =
    !state.selectedLocation.id ||
    !state.startDate ||
    !state.endDate ||
    (state.startDate &&
      state.endDate &&
      isBefore(state.endDate, state.startDate));

  const handleSearch = () => {
    if (!state.selectedLocation.id || !state.startDate || !state.endDate)
      return;
    const params = new URLSearchParams();
    params.set('city', state.selectedLocation.slug ?? '');
    params.set('checkin', format(state.startDate, 'yyyy-MM-dd'));
    params.set('checkout', format(state.endDate, 'yyyy-MM-dd'));
    if (state.promoCode) params.set('promoCode', state.promoCode);
    window.location.href = `/search?${params.toString()}`;
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Paper
        elevation={0} // no shadow
        sx={{
          p: { xs: 2, md: 2 }, // padding
          borderRadius: '50px',
          background:
            'linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05))',
          backdropFilter: 'blur(15px)',
          border: '1px solid rgba(255,255,255,0.3)',
          maxWidth: '100%',
        }}
      >
        <Grid container spacing={1} alignItems="center">
          <Grid size={{ xs: 12, md: 2.4 }}>
            <LocationSelector
              locations={locations}
              selectedLocation={state.selectedLocation}
              onLocationChange={(loc) =>
                dispatch({ type: 'SET_LOCATION', payload: loc })
              }
              isLoading={isLoading}
              error={error}
            />
          </Grid>

          <Grid size={{ xs: 12, md: 2.8 }}>
            <DateInput
              label="Select date"
              value={
                state.startDate
                  ? format(state.startDate, 'MMM dd, yyyy')
                  : 'Select date'
              }
              onClick={(e) =>
                dispatch({ type: 'OPEN_CALENDAR', payload: e.currentTarget })
              }
              icon={<EventAvailable />}
            />
          </Grid>

          <Grid size={{ xs: 12, md: 2.8 }}>
            <DateInput
              label={`Select date${nights > 0 ? ` (${nights} night${nights > 1 ? 's' : ''})` : ''}`}
              value={
                state.endDate
                  ? format(state.endDate, 'MMM dd, yyyy')
                  : 'Select date'
              }
              onClick={(e) =>
                dispatch({ type: 'OPEN_CALENDAR', payload: e.currentTarget })
              }
              icon={<EventBusy />}
            />
          </Grid>

          <Grid size={{ xs: 12, md: 2 }}>
            <TextField
              placeholder="Promo code"
              value={state.promoCode}
              onChange={(e) =>
                dispatch({ type: 'SET_PROMO_CODE', payload: e.target.value })
              }
              fullWidth
              sx={inputStyles}
              InputProps={{
                sx: { borderRadius: '12px' },
              }}
            />
          </Grid>

          <Grid size={{ xs: 12, md: 2 }} sx={{ alignSelf: 'center' }}>
            <Button
              variant="contained"
              onClick={handleSearch}
              fullWidth
              disabled={isSearchDisabled}
              sx={{
                height: 48,
                borderRadius: '30px',
                textTransform: 'none',
                fontWeight: 600,
                fontFamily: 'Inter, sans-serif',
                letterSpacing: '0.5px',
                background: 'primary.main',
                '&:hover': {
                  background: 'primary.dark',
                },
                '&:disabled': {
                  opacity: 0.5,
                  background: 'primary.main',
                  pointerEvents: 'none',
                },
              }}
            >
              Search
            </Button>
          </Grid>
        </Grid>

        <CalendarComponent
          open={Boolean(state.calendarAnchorEl)}
          anchorEl={state.calendarAnchorEl}
          onClose={() => dispatch({ type: 'CLOSE_CALENDAR' })}
          startDate={state.startDate}
          endDate={state.endDate}
          onDatesChange={(s, e) => {
            dispatch({ type: 'SET_START_DATE', payload: s });
            dispatch({ type: 'SET_END_DATE', payload: e });
          }}
        />
      </Paper>
    </LocalizationProvider>
  );
};
