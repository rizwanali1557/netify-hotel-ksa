"use client";

import {
  Wifi,
  Pool,
  LocalBar,
  Restaurant,
  Pets,
  LocalParking,
  FitnessCenter,
  Spa,
  RoomService,
  BusinessCenter,
  LocalLaundryService,
  ChildCare,
  Elevator,
  AcUnit,
  CreditCard,
  AirportShuttle,
  SupportAgent,
} from "@mui/icons-material";

export const facilityIcons: Record<string, React.ElementType> = {
  concierge: SupportAgent,
  bar: LocalBar,
  airport_shuttle: AirportShuttle,
  pets: Pets,
  childcare: ChildCare,
  pool: Pool,
  ac: AcUnit,
  elevator: Elevator,
  wifi: Wifi,
  credit_card: CreditCard,
  restaurant: Restaurant,
  fitness: FitnessCenter,
  spa: Spa,
  room_service: RoomService,
  parking: LocalParking,
  business: BusinessCenter,
  laundry: LocalLaundryService,
};

export function FacilityIcon({
  icon_key,
  fontSize = "small", // default smaller
}: {
  icon_key: string | null;
  fontSize?: "inherit" | "small" | "medium" | "large";
}) {
  if (!icon_key) return <span>❓</span>;

  const Icon = facilityIcons[icon_key];
  if (!Icon) return <span>❓</span>;

  return <Icon fontSize={fontSize} />;
}
